# TUTOR LEDGER — Independent Tutor Management System

A modern, responsive, full-featured web application designed for independent private home tutors to manage student records, class schedules, attendance tracking, fees, partial and full payments, balances, and overdue dues in one centralized dashboard.

Branded strictly as **TUTOR LEDGER**.

---

## 🌟 Key Features

### 1. Centralized Tutor Dashboard
- **8 Dynamic KPI Summary Cards**:
  1. Total Students & Active Tutees
  2. Classes Scheduled Today
  3. Classes Completed
  4. Attendance Rate (%)
  5. Total Fees Expected
  6. Total Payments Received
  7. Outstanding Balance
  8. Overdue Dues & Accounts
- **Today's Class Schedule** with quick "Mark Attendance" actions.
- **Monthly Fee Collection Chart** (dynamic SVG bar chart visualizing fees generated vs payments collected).
- **Students with Pending or Overdue Dues** table with one-click payment entry.
- **Recent Fee Payments** table with printable receipt access.
- **Upcoming Classes** (next 7 days) preview.

### 2. Comprehensive Student Management
- Auto-generated student IDs (`TL-YYYY-###`).
- Full profile details: student name, parent/guardian name, contact number, email, grade, subjects taught, enrollment date, preferred days/times, billing method, fee amount, and billing day.
- Search by student name, ID, phone number, subject, or grade.
- Filter by status (Active / Inactive) and payment status (Paid, Pending, Overdue).
- Sorting by name, highest balance, and enrollment date.
- **Detailed 6-Tab Student Profile**:
  1. *Overview & Ledger*: Personal details, fee arrangement, status.
  2. *Class Schedule*: All past and upcoming classes.
  3. *Attendance History*: Chronological presence records with notes.
  4. *Fee Calculation Audit*: Transparent mathematical breakdown of all charges and running balances.
  5. *Payments Made*: Ledger of all receipts.
  6. *Activity Log*: Complete chronological timeline from enrollment to latest transactions.

### 3. Transparent Fee Calculation Engine
- **Per-Class Billing**: Charges calculated from completed chargeable classes, honoring tutor's configurable absence and cancellation policies.
- **Monthly Fixed Billing**: Fixed monthly fee per active billing period, preventing duplicate charges.
- **Transparent Formula**: Outstanding Balance = Opening Balance + Total Fees Generated &minus; Total Payments Received.
- Historical fee amounts are preserved when arrangements change.

### 4. Class Scheduling & Interactive Calendar
- **Multiple Calendar Views**: Month View, Week View, Day View, and List View.
- Easy navigation across months and jump to "Today".
- **Conflict & Overlap Warning**: Automatically checks tutor's schedule and alerts on overlapping time slots.
- **Rescheduling History**: Preserves previous date/time timestamps when a session is moved.

### 5. Performance-Based Extra Academic Support Classes
- Schedule dedicated extra coaching sessions for students needing additional academic support.
- Record specific learning difficulties, test preparation needs, or topics.
- Toggle whether the extra class is chargeable or complimentary.
- Labeled with distinctive purple badges across the calendar and student profiles.

### 6. Class Attendance Tracker
- Mark attendance per scheduled class: **Present**, **Absent**, **Late**, **Excused**.
- Record session notes and homework assignments.
- Immediate real-time fee impact calculation for per-class billing students.
- Complete audit history table with student and status filters.

### 7. Payments, Dues & Printable Receipts
- Record partial or full payments.
- Supports payment methods: UPI (GPay/PhonePe/Paytm), Cash, Bank Transfer (NEFT/IMPS), Cheque, Other.
- Overpayment guard requiring confirmation if payment exceeds outstanding balance.
- **Official Printable Receipt Modal**: Formatted receipt with receipt number, student information, tutor details, itemized breakdown, and print styles.

### 8. In-App Notification Center
- Automated alerts for today's classes, upcoming fee due dates, overdue accounts, recorded payments, and extra support sessions.
- Unread badge counter in top header and sidebar.
- Dedicated notification center page with "Mark Read" and direct navigation links.

### 9. Reports & Analytics
- Live calculations from stored data.
- Student-wise breakdown table with collection metrics and attendance percentages.
- **Export to CSV**: Instant download of comprehensive financial and attendance report.
- **Print Report**: Optimized print view.

### 10. Settings & Preferences
- Tutor profile customization (name, title, contact, address).
- Default currency support (INR ₹, USD $, EUR €, GBP £, AED).
- Attendance and cancellation billing policy toggles.
- **Data Management**: Export full JSON backup, import JSON backup, or reset to realistic demo data.

---

## 🚀 How to Run Locally

Because **TUTOR LEDGER** is built using high-performance, modular Vanilla JavaScript, HTML5, and CSS:

### Option 1: Direct Browser Launch
Simply double-click `index.html` in Windows Explorer or open it in any modern browser (Chrome, Edge, Firefox, Brave, Safari). No web server or node installation is required!

### Option 2: Using Any Local Server (Optional)
```powershell
# Using Python
python -m http.server 3000

# Using Node.js npx serve
npx serve .
```
Then visit `http://localhost:3000`.

---

## 📂 Project Architecture

```
tutor ledger/
├── index.html          # Main application markup, modals, and templates
├── css/
│   └── style.css       # Complete modern design system and print styling
├── js/
│   ├── store.js        # Reactive data store, calculations, LocalStorage persistence
│   ├── dashboard.js    # Dashboard KPIs, today's schedule, SVG chart, dues widget
│   ├── students.js     # Student directory, filtering, 6-tab profile drawer
│   ├── schedule.js     # Month/Week/Day calendar, conflict detector, extra classes
│   ├── attendance.js   # Class roster attendance marker, fee updates, audit log
│   ├── payments.js     # Receivables ledger, payment recorder, printable receipt
│   ├── reports.js      # Reports, summary analytics, CSV exporter
│   ├── settings.js     # Profile, policies, JSON backup/restore
│   └── app.js          # SPA router, global search, notifications, toasts, modals
└── README.md           # Documentation and guide
```

---

## 🔒 Git Commands to Push to GitHub

To push this complete project to your repository (`https://github.com/Indusree2097/althon2.0.git`), open PowerShell in this folder and run:

```powershell
git init
git remote remove origin 2>$null
git remote add origin https://github.com/Indusree2097/althon2.0.git
git add -A
git commit -m "Build complete Tutor Ledger management application"
git branch -M main
git push -u origin main --force
```
