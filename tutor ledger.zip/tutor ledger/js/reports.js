/**
 * TUTOR LEDGER — Reports & History Controller
 * Aggregates financial analytics, student performance, attendance statistics,
 * CSV data export, and printable financial statements from live store data.
 */

(function () {
  'use strict';

  function initReports() {
    setupEventListeners();
    populateStudentFilter();
    renderReports();
  }

  function setupEventListeners() {
    document.getElementById('report-period-select')?.addEventListener('change', renderReports);
    document.getElementById('report-student-select')?.addEventListener('change', renderReports);

    // Export CSV
    document.getElementById('btn-export-reports-csv')?.addEventListener('click', exportReportsCSV);

    // Print Report
    document.getElementById('btn-print-report')?.addEventListener('click', () => {
      window.print();
    });
  }

  function populateStudentFilter() {
    const select = document.getElementById('report-student-select');
    if (!select) return;

    const students = window.TLStore.getStudents();
    select.innerHTML = '<option value="all">All Students</option>' +
      students.map(s => `<option value="${s.id}">${s.name} (${s.id})</option>`).join('');
  }

  function renderReports() {
    const period = document.getElementById('report-period-select')?.value || 'this_month';
    const studentFilter = document.getElementById('report-student-select')?.value || 'all';

    let students = window.TLStore.getStudents();
    if (studentFilter !== 'all') {
      students = students.filter(s => s.id === studentFilter);
    }

    let totalBilled = 0;
    let totalCollected = 0;
    let totalOutstanding = 0;
    let totalClassesConducted = 0;
    let extraClassesCount = 0;

    const reportRows = students.map(s => {
      const ledger = window.TLStore.calculateStudentLedger(s.id);
      totalBilled += ledger.totalFees;
      totalCollected += ledger.totalPaid;
      totalOutstanding += ledger.balance;

      // Attendance for this student
      const att = window.TLStore.getAttendanceByStudentId(s.id);
      const studentClasses = window.TLStore.getClasses().filter(c => c.studentId === s.id);
      const completed = studentClasses.filter(c => c.status === 'completed');
      const extra = studentClasses.filter(c => c.isExtra);

      totalClassesConducted += completed.length;
      extraClassesCount += extra.length;

      const presentCount = att.filter(a => a.status === 'Present' || a.status === 'Late').length;
      const attRate = att.length > 0 ? Math.round((presentCount / att.length) * 100) : 100;

      let statusBadge = '<span class="badge badge-success">Paid</span>';
      if (ledger.balance > 0) {
        if (ledger.isOverdue) statusBadge = '<span class="badge badge-danger">Overdue</span>';
        else if (ledger.totalPaid > 0) statusBadge = '<span class="badge badge-warning">Partial</span>';
        else statusBadge = '<span class="badge badge-warning">Pending</span>';
      }

      return {
        student: s,
        ledger: ledger,
        classesTaken: completed.length,
        attRate: attRate,
        statusBadge: statusBadge
      };
    });

    // Update KPI strip
    const elFees = document.getElementById('rep-total-fees');
    const elCol = document.getElementById('rep-total-collected');
    const elOut = document.getElementById('rep-total-outstanding');
    const elClasses = document.getElementById('rep-classes-conducted');
    const elPct = document.getElementById('rep-collection-pct');
    const elExtra = document.getElementById('rep-extra-classes-sub');

    if (elFees) elFees.textContent = window.TLStore.formatCurrency(totalBilled);
    if (elCol) elCol.textContent = window.TLStore.formatCurrency(totalCollected);
    if (elOut) elOut.textContent = window.TLStore.formatCurrency(totalOutstanding);
    if (elClasses) elClasses.textContent = totalClassesConducted;

    const colRate = totalBilled > 0 ? Math.round((totalCollected / totalBilled) * 100) : 100;
    if (elPct) elPct.textContent = `${colRate}% Collection Efficiency`;
    if (elExtra) elExtra.textContent = `${extraClassesCount} Extra Support Classes`;

    // Render Student-Wise Report Table
    const tbody = document.getElementById('reports-student-tbody');
    if (!tbody) return;

    if (reportRows.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted p-4">No student records found.</td></tr>';
      return;
    }

    tbody.innerHTML = reportRows.map(r => {
      const s = r.student;
      const l = r.ledger;

      return `
        <tr>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${s.id}')">
              ${s.name}
            </a>
            <div class="text-muted font-size-11">${s.id}</div>
          </td>
          <td>
            ${s.grade}
            <div class="text-muted font-size-11">${s.subjects}</div>
          </td>
          <td>${s.billingMethod === 'per_class' ? 'Per-Class' : 'Monthly'} (${window.TLStore.formatCurrency(s.feeAmount)})</td>
          <td class="font-weight-600 text-center">${r.classesTaken}</td>
          <td>
            <div style="display:flex; align-items:center; gap: 6px;">
              <div style="flex:1; height:6px; background:#e2e8f0; border-radius:3px; overflow:hidden;">
                <div style="width: ${r.attRate}%; height:100%; background: ${r.attRate >= 80 ? '#10b981' : '#f59e0b'};"></div>
              </div>
              <span class="font-size-12 font-weight-600">${r.attRate}%</span>
            </div>
          </td>
          <td class="font-weight-600">${window.TLStore.formatCurrency(l.totalFees)}</td>
          <td class="font-weight-600 text-success">${window.TLStore.formatCurrency(l.totalPaid)}</td>
          <td class="font-weight-700 ${l.balance > 0 ? (l.isOverdue ? 'text-danger' : 'text-warning') : 'text-success'}">
            ${window.TLStore.formatCurrency(l.balance)}
          </td>
          <td>${r.statusBadge}</td>
        </tr>
      `;
    }).join('');
  }

  // Export CSV Functionality
  function exportReportsCSV() {
    const students = window.TLStore.getStudents();
    if (students.length === 0) {
      window.TLApp.showToast('No data available to export.', 'warning');
      return;
    }

    const headers = [
      'Student ID',
      'Student Name',
      'Parent Name',
      'Phone',
      'Grade',
      'Subjects',
      'Billing Method',
      'Fee Rate',
      'Total Fees Invoiced',
      'Total Payments Received',
      'Outstanding Balance',
      'Payment Status',
      'Attendance Rate (%)'
    ];

    const rows = students.map(s => {
      const ledger = window.TLStore.calculateStudentLedger(s.id);
      const att = window.TLStore.getAttendanceByStudentId(s.id);
      const presentCount = att.filter(a => a.status === 'Present' || a.status === 'Late').length;
      const attRate = att.length > 0 ? Math.round((presentCount / att.length) * 100) : 100;

      return [
        s.id,
        `"${s.name}"`,
        `"${s.parentName}"`,
        `"${s.phone}"`,
        `"${s.grade}"`,
        `"${s.subjects}"`,
        s.billingMethod,
        s.feeAmount,
        ledger.totalFees,
        ledger.totalPaid,
        ledger.balance,
        ledger.status,
        `${attRate}%`
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TUTOR_LEDGER_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    window.TLApp.showToast('CSV Report exported successfully!', 'success');
  }

  // Expose controller
  window.TLReports = {
    init: initReports,
    refresh: renderReports,
    exportCSV: exportReportsCSV
  };

  window.TLStore.subscribe(() => {
    populateStudentFilter();
    renderReports();
  });
})();
