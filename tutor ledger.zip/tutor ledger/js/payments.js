/**
 * TUTOR LEDGER — Payments & Dues Controller
 * Handles student receivables ledger, dues table, partial & full payment recording,
 * overpayment validation, and official printable receipt generation.
 */

(function () {
  'use strict';

  function initPayments() {
    setupEventListeners();
    populatePaymentStudentSelect();
    renderFinancialBanner();
    renderDuesTable();
    renderPaymentsHistoryTable();
  }

  function setupEventListeners() {
    // Record Payment Button
    document.getElementById('btn-open-record-payment-modal')?.addEventListener('click', () => {
      openRecordPaymentModal();
    });

    // Student selection in Payment Modal
    const studentSelect = document.getElementById('pay-student');
    if (studentSelect) {
      studentSelect.addEventListener('change', () => {
        handlePaymentStudentChange(studentSelect.value);
      });
    }

    // Pay full balance button
    document.getElementById('btn-fill-full-balance')?.addEventListener('click', () => {
      const studentId = document.getElementById('pay-student')?.value;
      if (studentId) {
        const ledger = window.TLStore.calculateStudentLedger(studentId);
        const amountInput = document.getElementById('pay-amount');
        if (amountInput) amountInput.value = ledger.balance;
        checkOverpaymentAlert();
      }
    });

    // Amount input change (overpayment check)
    document.getElementById('pay-amount')?.addEventListener('input', checkOverpaymentAlert);

    // Payment Form Submit
    document.getElementById('form-payment')?.addEventListener('submit', handlePaymentSubmit);

    // Dues Status Filter
    document.getElementById('dues-status-filter')?.addEventListener('change', renderDuesTable);

    // Search payments history
    document.getElementById('payments-history-search')?.addEventListener('input', renderPaymentsHistoryTable);

    // Print Receipt Action button
    document.getElementById('btn-print-receipt-action')?.addEventListener('click', () => {
      window.print();
    });
  }

  function populatePaymentStudentSelect(selectedStudentId = null) {
    const select = document.getElementById('pay-student');
    if (!select) return;

    const students = window.TLStore.getStudents().filter(s => s.status === 'active');
    select.innerHTML = '<option value="">-- Choose student --</option>' +
      students.map(s => {
        const ledger = window.TLStore.calculateStudentLedger(s.id);
        const balStr = ledger.balance > 0 ? ` (Balance: ${window.TLStore.formatCurrency(ledger.balance)})` : ' (Settled)';
        return `
          <option value="${s.id}" ${s.id === selectedStudentId ? 'selected' : ''}>
            ${s.name} ${balStr}
          </option>
        `;
      }).join('');
  }

  function handlePaymentStudentChange(studentId) {
    const box = document.getElementById('pay-student-balance-box');
    const fullBtn = document.getElementById('btn-fill-full-balance');
    const balEl = document.getElementById('pay-current-outstanding');
    const cycleEl = document.getElementById('pay-billing-cycle-info');
    const appliedInput = document.getElementById('pay-applied-to');
    const amountInput = document.getElementById('pay-amount');

    if (!studentId) {
      if (box) box.style.display = 'none';
      if (fullBtn) fullBtn.style.display = 'none';
      return;
    }

    const student = window.TLStore.getStudentById(studentId);
    const ledger = window.TLStore.calculateStudentLedger(studentId);

    if (box) box.style.display = 'block';
    if (balEl) balEl.textContent = window.TLStore.formatCurrency(ledger.balance);
    if (cycleEl) {
      cycleEl.textContent = student.billingMethod === 'per_class'
        ? `Per-Class Billing (${window.TLStore.formatCurrency(student.feeAmount)}/class)`
        : `Monthly Fixed Billing (${window.TLStore.formatCurrency(student.feeAmount)}/month)`;
    }

    // Default amount to outstanding balance if > 0
    if (amountInput && ledger.balance > 0) {
      amountInput.value = ledger.balance;
      if (fullBtn) fullBtn.style.display = 'inline-block';
    }

    // Suggest applied-to text
    if (appliedInput && !appliedInput.value) {
      const currentMonth = new Date().toLocaleString('default', { month: 'long', year: 'numeric' });
      appliedInput.value = `${currentMonth} Tuition Fee Settlement`;
    }

    checkOverpaymentAlert();
  }

  function checkOverpaymentAlert() {
    const studentId = document.getElementById('pay-student')?.value;
    const amount = Number(document.getElementById('pay-amount')?.value) || 0;
    const alertBox = document.getElementById('pay-overpayment-alert');
    if (!studentId || !alertBox) return;

    const ledger = window.TLStore.calculateStudentLedger(studentId);
    if (amount > ledger.balance && ledger.balance > 0) {
      alertBox.style.display = 'block';
      document.getElementById('pay-overpay-entered').textContent = window.TLStore.formatCurrency(amount);
      document.getElementById('pay-overpay-balance').textContent = window.TLStore.formatCurrency(ledger.balance);
    } else {
      alertBox.style.display = 'none';
    }
  }

  // 1. Render Financial Banner Strip
  function renderFinancialBanner() {
    const metrics = window.TLStore.getDashboardMetrics();

    const elTotal = document.getElementById('paystat-total-fees');
    const elRec = document.getElementById('paystat-total-received');
    const elOut = document.getElementById('paystat-total-outstanding');
    const elOvd = document.getElementById('paystat-total-overdue');

    if (elTotal) elTotal.textContent = window.TLStore.formatCurrency(metrics.totalFeesExpected);
    if (elRec) elRec.textContent = window.TLStore.formatCurrency(metrics.totalPaymentsReceived);
    if (elOut) elOut.textContent = window.TLStore.formatCurrency(metrics.totalOutstanding);
    if (elOvd) elOvd.textContent = window.TLStore.formatCurrency(metrics.totalOverdue);
  }

  // 2. Render Dues Table
  function renderDuesTable() {
    const tbody = document.getElementById('dues-table-tbody');
    const filter = document.getElementById('dues-status-filter')?.value || 'all';
    if (!tbody) return;

    const students = window.TLStore.getStudents();
    let rows = [];

    students.forEach(s => {
      const ledger = window.TLStore.calculateStudentLedger(s.id);

      if (filter === 'overdue' && (!ledger.isOverdue || ledger.balance === 0)) return;
      if (filter === 'pending' && (ledger.balance === 0 || ledger.isOverdue)) return;
      if (filter === 'paid' && ledger.balance > 0) return;

      rows.push({
        student: s,
        ledger: ledger
      });
    });

    if (rows.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted p-4">No fee dues matching the selected filter.</td></tr>';
      return;
    }

    // Sort overdue first, then highest balance
    rows.sort((a, b) => {
      if (a.ledger.isOverdue && !b.ledger.isOverdue) return -1;
      if (!a.ledger.isOverdue && b.ledger.isOverdue) return 1;
      return b.ledger.balance - a.ledger.balance;
    });

    tbody.innerHTML = rows.map(item => {
      const s = item.student;
      const l = item.ledger;

      let statusBadge = '<span class="badge badge-success">Paid</span>';
      if (l.balance > 0) {
        if (l.isOverdue) statusBadge = '<span class="badge badge-danger">Overdue</span>';
        else if (l.totalPaid > 0) statusBadge = '<span class="badge badge-warning">Partially Paid</span>';
        else statusBadge = '<span class="badge badge-warning">Pending</span>';
      }

      const cycleDesc = s.billingMethod === 'per_class'
        ? `${l.entries.filter(e => e.chargeable).length} Completed Classes`
        : `Monthly Cycle (${l.entries.length} Periods)`;

      return `
        <tr>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${s.id}')">
              ${s.name}
            </a>
            <div class="text-muted font-size-11">${s.id} • ${s.grade}</div>
          </td>
          <td>
            ${s.billingMethod === 'per_class' ? 'Per-Class' : 'Monthly Fixed'}
            <div class="text-muted font-size-11">${window.TLStore.formatCurrency(s.feeAmount)} rate</div>
          </td>
          <td>
            ${cycleDesc}
            <div class="text-muted font-size-11">Due day: ${s.dueDay}th</div>
          </td>
          <td class="font-weight-600">${window.TLStore.formatCurrency(l.totalFees)}</td>
          <td class="font-weight-600 text-success">${window.TLStore.formatCurrency(l.totalPaid)}</td>
          <td class="font-weight-700 ${l.balance > 0 ? (l.isOverdue ? 'text-danger' : 'text-warning') : 'text-success'}">
            ${window.TLStore.formatCurrency(l.balance)}
          </td>
          <td class="font-size-12 text-muted">${l.nextDueDate || '—'}</td>
          <td>${statusBadge}</td>
          <td>
            <div class="flex-wrap-gap">
              <button class="btn btn-primary btn-xs" onclick="window.TLPayments.openRecordPaymentModal('${s.id}')">
                Record Pay
              </button>
              <button class="btn btn-outline btn-xs" onclick="window.TLStudents.openProfile('${s.id}')">
                Audit
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // 3. Render Payments History Table
  function renderPaymentsHistoryTable() {
    const tbody = document.getElementById('payments-history-tbody');
    const search = (document.getElementById('payments-history-search')?.value || '').toLowerCase().trim();
    if (!tbody) return;

    let payments = window.TLStore.getPayments().slice().reverse();

    if (search) {
      payments = payments.filter(p => {
        return (
          p.studentName.toLowerCase().includes(search) ||
          p.id.toLowerCase().includes(search) ||
          (p.ref && p.ref.toLowerCase().includes(search)) ||
          (p.method && p.method.toLowerCase().includes(search))
        );
      });
    }

    if (payments.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted p-4">No payment transactions found.</td></tr>';
      return;
    }

    tbody.innerHTML = payments.map(p => {
      return `
        <tr>
          <td><span class="badge badge-indigo font-mono font-size-11">${p.id}</span></td>
          <td>${p.date}</td>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${p.studentId}')">
              ${p.studentName}
            </a>
          </td>
          <td class="font-weight-700 text-success font-size-14">${window.TLStore.formatCurrency(p.amount)}</td>
          <td><span class="badge badge-neutral">${p.method}</span></td>
          <td class="font-mono font-size-12 text-muted">${p.ref || '—'}</td>
          <td class="font-size-12">${p.appliedTo || '—'}</td>
          <td>
            <button class="btn btn-outline btn-xs" onclick="window.TLPayments.viewReceipt('${p.id}')">
              Receipt
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // 4. Open Record Payment Modal
  function openRecordPaymentModal(studentId = null) {
    const form = document.getElementById('form-payment');
    if (!form) return;

    form.reset();
    populatePaymentStudentSelect(studentId);

    const dateInput = document.getElementById('pay-date');
    if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];

    if (studentId) {
      const select = document.getElementById('pay-student');
      if (select) {
        select.value = studentId;
        handlePaymentStudentChange(studentId);
      }
    } else {
      const box = document.getElementById('pay-student-balance-box');
      if (box) box.style.display = 'none';
      const alertBox = document.getElementById('pay-overpayment-alert');
      if (alertBox) alertBox.style.display = 'none';
    }

    window.TLApp.openModal('modal-payment');
  }

  // 5. Handle Payment Form Submit
  function handlePaymentSubmit(e) {
    e.preventDefault();

    const studentId = document.getElementById('pay-student').value;
    const amount = Number(document.getElementById('pay-amount').value);
    const date = document.getElementById('pay-date').value;
    const method = document.getElementById('pay-method').value;
    const ref = document.getElementById('pay-ref').value.trim();
    const appliedTo = document.getElementById('pay-applied-to').value.trim();
    const notes = document.getElementById('pay-notes').value.trim();

    if (!studentId || isNaN(amount) || amount <= 0 || !date || !appliedTo) {
      window.TLApp.showToast('Please fill all required payment fields correctly.', 'warning');
      return;
    }

    const student = window.TLStore.getStudentById(studentId);
    const studentName = student ? student.name : 'Student';

    const newPayment = window.TLStore.recordPayment({
      studentId,
      studentName,
      amount,
      date,
      method,
      ref,
      appliedTo,
      notes
    });

    window.TLApp.closeModal('modal-payment');
    window.TLApp.showToast(`Payment of ${window.TLStore.formatCurrency(amount)} recorded for ${studentName}!`, 'success');

    // Automatically display printable payment receipt
    viewReceipt(newPayment.id);
  }

  // 6. View & Print Payment Receipt
  function viewReceipt(paymentId) {
    const payment = (window.TLStore.getPayments() || []).find(p => p.id === paymentId);
    if (!payment) {
      window.TLApp.showToast('Receipt record not found.', 'danger');
      return;
    }

    const student = window.TLStore.getStudentById(payment.studentId);
    const settings = window.TLStore.getSettings();
    const ledger = student ? window.TLStore.calculateStudentLedger(student.id) : { balance: 0 };

    // Fill receipt fields
    document.getElementById('rec-number').textContent = payment.id;
    document.getElementById('rec-date').textContent = new Date(payment.date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });

    document.getElementById('rec-tutor-name').textContent = settings.tutorName;
    document.getElementById('rec-tutor-title').textContent = settings.tutorTitle;
    document.getElementById('rec-tutor-phone').textContent = settings.phone;

    document.getElementById('rec-student-name').textContent = payment.studentName;
    document.getElementById('rec-student-id').textContent = `ID: ${payment.studentId} • ${student ? student.grade : ''}`;
    document.getElementById('rec-parent-name').textContent = `Parent: ${student ? student.parentName : '—'}`;

    document.getElementById('rec-method').textContent = payment.method;
    document.getElementById('rec-ref').textContent = payment.ref || 'Direct Settlement';
    document.getElementById('rec-period').textContent = payment.appliedTo;

    document.getElementById('rec-item-desc').textContent = payment.appliedTo;
    document.getElementById('rec-notes').textContent = payment.notes || 'Tuition fee acknowledged with thanks.';
    document.getElementById('rec-amount').textContent = window.TLStore.formatCurrency(payment.amount);

    const remBalEl = document.getElementById('rec-remaining-balance');
    if (remBalEl) {
      remBalEl.textContent = window.TLStore.formatCurrency(ledger.balance);
      remBalEl.className = ledger.balance === 0 ? 'text-success' : 'text-warning';
    }

    window.TLApp.openModal('modal-receipt');
  }

  // Expose controller
  window.TLPayments = {
    init: initPayments,
    refresh: () => {
      renderFinancialBanner();
      renderDuesTable();
      renderPaymentsHistoryTable();
    },
    openRecordPaymentModal: openRecordPaymentModal,
    viewReceipt: viewReceipt
  };

  window.TLStore.subscribe(() => {
    populatePaymentStudentSelect();
    renderFinancialBanner();
    renderDuesTable();
    renderPaymentsHistoryTable();
  });
})();
