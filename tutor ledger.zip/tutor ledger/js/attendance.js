/**
 * TUTOR LEDGER — Attendance Management Controller
 * Handles class date selection, roster loading, marking Present/Absent/Late/Excused,
 * real-time fee impact recalculation, session notes, and audit history.
 */

(function () {
  'use strict';

  let currentLoadedClassId = null;
  let activeStatusSelected = 'Present';

  function initAttendance() {
    setupEventListeners();
    initDateAndClassPickers();
    renderAttendanceHistory();
  }

  function setupEventListeners() {
    const datePicker = document.getElementById('att-date-picker');
    if (datePicker) {
      datePicker.addEventListener('change', () => {
        loadClassesForDate(datePicker.value);
      });
    }

    const btnLoadClass = document.getElementById('btn-load-class-attendance');
    if (btnLoadClass) {
      btnLoadClass.addEventListener('click', () => {
        const classSelect = document.getElementById('att-class-select');
        if (classSelect && classSelect.value) {
          loadAttendancePanel(classSelect.value);
        } else {
          window.TLApp.showToast('Please select a scheduled class from the list.', 'warning');
        }
      });
    }

    // Status selection buttons (Present, Absent, Late, Excused)
    const statusBtns = document.querySelectorAll('.btn-att-status');
    statusBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        statusBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeStatusSelected = btn.getAttribute('data-status');
      });
    });

    // Save Attendance Record Button
    const btnSave = document.getElementById('btn-save-attendance-record');
    if (btnSave) {
      btnSave.addEventListener('click', handleSaveAttendance);
    }

    // Filter listeners on history table
    document.getElementById('att-history-filter-student')?.addEventListener('change', renderAttendanceHistory);
    document.getElementById('att-history-filter-status')?.addEventListener('change', renderAttendanceHistory);
  }

  function initDateAndClassPickers() {
    const datePicker = document.getElementById('att-date-picker');
    if (datePicker) {
      const today = new Date().toISOString().split('T')[0];
      datePicker.value = today;
      loadClassesForDate(today);
    }
  }

  function loadClassesForDate(dateStr) {
    const classSelect = document.getElementById('att-class-select');
    if (!classSelect) return;

    const classes = window.TLStore.getClasses().filter(c => c.date === dateStr && c.status !== 'cancelled');

    if (classes.length === 0) {
      classSelect.innerHTML = '<option value="">-- No classes scheduled for this date --</option>';
      return;
    }

    classSelect.innerHTML = '<option value="">-- Choose scheduled class (' + classes.length + ' available) --</option>' +
      classes.map(c => `
        <option value="${c.id}">
          ${c.startTime} - ${c.endTime}: ${c.studentName} (${c.subject}) ${c.isExtra ? '[Extra Class]' : ''}
        </option>
      `).join('');
  }

  function loadAttendancePanel(classId) {
    const cls = window.TLStore.getClassById(classId);
    if (!cls) return;

    currentLoadedClassId = cls.id;
    const panel = document.getElementById('att-marking-panel');
    if (panel) panel.style.display = 'block';

    // Populate Class Meta
    document.getElementById('att-info-title').textContent = `${cls.subject} — ${cls.studentName}`;
    document.getElementById('att-info-time').textContent = `${cls.date} • ${cls.startTime} - ${cls.endTime} • ${cls.mode === 'online' ? 'Online' : 'In-Person'} (${cls.venue || "Studio"})`;

    const extraBadge = document.getElementById('att-info-badge');
    if (extraBadge) {
      if (cls.isExtra) {
        extraBadge.textContent = 'Performance Extra Class';
        extraBadge.className = 'badge badge-purple';
      } else {
        extraBadge.textContent = 'Regular Class';
        extraBadge.className = 'badge badge-primary';
      }
    }

    // Populate Student Meta
    const student = window.TLStore.getStudentById(cls.studentId);
    if (student) {
      document.getElementById('att-student-avatar').textContent = student.name.split(' ').map(n => n[0]).join('').substring(0, 2);
      document.getElementById('att-student-name').textContent = student.name;
      document.getElementById('att-student-id').textContent = `${student.id} • ${student.grade}`;

      const billingNote = document.getElementById('att-billing-note');
      if (billingNote) {
        if (student.billingMethod === 'per_class') {
          billingNote.textContent = `Billing Rule: Per-Class (${window.TLStore.formatCurrency(student.feeAmount)}/class)`;
        } else {
          billingNote.textContent = `Billing Rule: Monthly Fixed (${window.TLStore.formatCurrency(student.feeAmount)}/month)`;
        }
      }
    }

    // Check existing attendance
    const existingAtt = window.TLStore.getAttendanceByClassId(cls.id);
    const statusBtns = document.querySelectorAll('.btn-att-status');
    statusBtns.forEach(b => b.classList.remove('active'));

    if (existingAtt) {
      activeStatusSelected = existingAtt.status;
      const targetBtn = document.querySelector(`.btn-att-status[data-status="${existingAtt.status}"]`);
      if (targetBtn) targetBtn.classList.add('active');
      document.getElementById('att-notes-input').value = existingAtt.notes || '';
    } else {
      activeStatusSelected = 'Present';
      const defaultBtn = document.querySelector('.btn-att-status[data-status="Present"]');
      if (defaultBtn) defaultBtn.classList.add('active');
      document.getElementById('att-notes-input').value = '';
    }

    panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function handleSaveAttendance() {
    if (!currentLoadedClassId) {
      window.TLApp.showToast('Please load a scheduled class first.', 'warning');
      return;
    }

    const cls = window.TLStore.getClassById(currentLoadedClassId);
    if (!cls) return;

    const notes = document.getElementById('att-notes-input')?.value.trim() || '';

    const saved = window.TLStore.saveAttendance({
      classId: cls.id,
      studentId: cls.studentId,
      date: cls.date,
      status: activeStatusSelected,
      notes: notes
    });

    window.TLApp.showToast(`Attendance marked as "${activeStatusSelected}" for ${cls.studentName}! Fee ledger updated.`, 'success');
    renderAttendanceHistory();

    // Scroll to audit table
    document.getElementById('att-history-tbody')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  // Render Attendance Audit History
  function renderAttendanceHistory() {
    const tbody = document.getElementById('att-history-tbody');
    const studentFilter = document.getElementById('att-history-filter-student')?.value || 'all';
    const statusFilter = document.getElementById('att-history-filter-status')?.value || 'all';
    if (!tbody) return;

    // Populate student filter dropdown
    const studentSelect = document.getElementById('att-history-filter-student');
    if (studentSelect && studentSelect.options.length <= 1) {
      const students = window.TLStore.getStudents();
      students.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.name;
        studentSelect.appendChild(opt);
      });
    }

    let records = window.TLStore.getAttendance();

    if (studentFilter !== 'all') {
      records = records.filter(r => r.studentId === studentFilter);
    }

    if (statusFilter !== 'all') {
      records = records.filter(r => r.status === statusFilter);
    }

    records.sort((a, b) => (b.date + (b.timestamp || '')).localeCompare(a.date + (a.timestamp || '')));

    if (records.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted p-4">No attendance history matching the filters.</td></tr>';
      return;
    }

    const settings = window.TLStore.getSettings();

    tbody.innerHTML = records.map(att => {
      const cls = window.TLStore.getClassById(att.classId);
      const student = window.TLStore.getStudentById(att.studentId);
      const studentName = student ? student.name : 'Student';
      const subject = cls ? cls.subject : 'Class';

      let statusBadge = '<span class="badge badge-success">Present</span>';
      if (att.status === 'Absent') statusBadge = '<span class="badge badge-danger">Absent</span>';
      else if (att.status === 'Late') statusBadge = '<span class="badge badge-warning">Late</span>';
      else if (att.status === 'Excused') statusBadge = '<span class="badge badge-indigo">Excused</span>';

      // Fee Impact calculation
      let feeImpact = '—';
      if (student && student.billingMethod === 'per_class') {
        if (att.status === 'Present' || att.status === 'Late') {
          feeImpact = `<span class="text-success font-weight-600">+${window.TLStore.formatCurrency(student.feeAmount)} (Billed)</span>`;
        } else if (att.status === 'Absent') {
          if (settings.chargeAbsent) {
            feeImpact = `<span class="text-warning font-weight-600">+${window.TLStore.formatCurrency(student.feeAmount)} (Policy)</span>`;
          } else {
            feeImpact = '<span class="text-muted">₹0 (Waived)</span>';
          }
        } else {
          feeImpact = '<span class="text-muted">₹0 (Excused)</span>';
        }
      } else if (student) {
        feeImpact = '<span class="text-muted">Monthly Fixed</span>';
      }

      return `
        <tr>
          <td><span class="font-weight-600">${att.date}</span></td>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${att.studentId}')">
              ${studentName}
            </a>
          </td>
          <td>${subject}</td>
          <td>
            ${cls && cls.isExtra ? '<span class="badge badge-purple">Extra Class</span>' : '<span class="badge badge-neutral">Regular</span>'}
          </td>
          <td>${statusBadge}</td>
          <td>${feeImpact}</td>
          <td class="font-size-12 text-muted">${att.notes || '—'}</td>
          <td>
            <button class="btn btn-outline btn-xs" onclick="window.TLAttendance.openAttendanceForClass('${att.classId}')">
              Edit
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // Public method called from other modules/buttons
  function openAttendanceForClass(classId) {
    const cls = window.TLStore.getClassById(classId);
    if (!cls) return;

    window.TLApp.navigateTo('attendance');

    const datePicker = document.getElementById('att-date-picker');
    if (datePicker) {
      datePicker.value = cls.date;
      loadClassesForDate(cls.date);
    }

    const classSelect = document.getElementById('att-class-select');
    if (classSelect) {
      classSelect.value = cls.id;
    }

    loadAttendancePanel(cls.id);
  }

  // Expose controller
  window.TLAttendance = {
    init: initAttendance,
    refresh: renderAttendanceHistory,
    openAttendanceForClass: openAttendanceForClass
  };

  window.TLStore.subscribe(() => {
    renderAttendanceHistory();
  });
})();
