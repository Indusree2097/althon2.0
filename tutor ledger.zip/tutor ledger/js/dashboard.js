/**
 * TUTOR LEDGER — Dashboard Controller
 * Updates 8 KPI cards, dynamic schedule timeline, overdue accounts,
 * recent payments, and SVG monthly fee collection trends chart.
 */

(function () {
  'use strict';

  function initDashboard() {
    renderKPIs();
    renderTodaySchedule();
    renderMonthlyChart();
    renderPendingDues();
    renderRecentPayments();
    renderUpcomingClasses();
  }

  // 1. Render 8 KPI Summary Cards
  function renderKPIs() {
    const metrics = window.TLStore.getDashboardMetrics();
    const settings = window.TLStore.getSettings();

    // Tutor greeting
    const greetEl = document.getElementById('dash-greeting-name');
    if (greetEl) {
      greetEl.textContent = settings.tutorName || 'Tutor';
    }

    // 1. Total Students
    const elTotalStudents = document.getElementById('kpi-total-students');
    const elActiveSub = document.getElementById('kpi-active-students-sub');
    if (elTotalStudents) elTotalStudents.textContent = metrics.totalStudents;
    if (elActiveSub) elActiveSub.textContent = `${metrics.activeStudents} Active Tutees`;

    // 2. Classes Scheduled Today
    const elClassesToday = document.getElementById('kpi-classes-today');
    if (elClassesToday) elClassesToday.textContent = metrics.classesToday;

    // 3. Classes Completed
    const elClassesCompleted = document.getElementById('kpi-classes-completed');
    if (elClassesCompleted) elClassesCompleted.textContent = metrics.classesCompleted;

    // 4. Attendance Rate
    const elAttRate = document.getElementById('kpi-attendance-rate');
    if (elAttRate) elAttRate.textContent = `${metrics.attendanceRate}%`;

    // 5. Total Fees Expected
    const elFeesExp = document.getElementById('kpi-fees-expected');
    if (elFeesExp) elFeesExp.textContent = window.TLStore.formatCurrency(metrics.totalFeesExpected);

    // 6. Total Payments Received
    const elPayRec = document.getElementById('kpi-payments-received');
    if (elPayRec) elPayRec.textContent = window.TLStore.formatCurrency(metrics.totalPaymentsReceived);

    // 7. Outstanding Balance
    const elOutBal = document.getElementById('kpi-outstanding-balance');
    if (elOutBal) elOutBal.textContent = window.TLStore.formatCurrency(metrics.totalOutstanding);

    // 8. Overdue Dues
    const elOverdue = document.getElementById('kpi-overdue-dues');
    const elOverdueSub = document.getElementById('kpi-overdue-count-sub');
    if (elOverdue) elOverdue.textContent = window.TLStore.formatCurrency(metrics.totalOverdue);
    if (elOverdueSub) elOverdueSub.textContent = `${metrics.overdueAccountsCount} accounts overdue`;

    // Sidebar badges
    const navStudentsCount = document.getElementById('nav-students-count');
    if (navStudentsCount) navStudentsCount.textContent = metrics.activeStudents;

    const navTodayCount = document.getElementById('nav-today-count');
    if (navTodayCount) navTodayCount.textContent = metrics.classesToday;

    const navOverdueCount = document.getElementById('nav-overdue-count');
    if (navOverdueCount) {
      if (metrics.overdueAccountsCount > 0) {
        navOverdueCount.style.display = 'inline-flex';
        navOverdueCount.textContent = metrics.overdueAccountsCount;
      } else {
        navOverdueCount.style.display = 'none';
      }
    }
  }

  // 2. Render Today's Class Schedule
  function renderTodaySchedule() {
    const listContainer = document.getElementById('dash-today-schedule-list');
    const dateLabel = document.getElementById('dash-schedule-date-str');
    if (!listContainer) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const todayFormatted = new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
    if (dateLabel) dateLabel.textContent = todayFormatted;

    const classes = window.TLStore.getClasses();
    const todayClasses = classes.filter(c => c.date === todayStr && c.status !== 'cancelled');

    if (todayClasses.length === 0) {
      listContainer.innerHTML = `
        <div class="empty-state p-3">
          <p class="text-muted">No classes scheduled for today.</p>
          <button class="btn btn-outline btn-xs mt-2" onclick="window.TLSchedule.openScheduleModal(null, '${todayStr}')">+ Schedule Class for Today</button>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = todayClasses.map(cls => {
      const att = window.TLStore.getAttendanceByClassId(cls.id);
      let statusBadge = '<span class="badge badge-neutral">Scheduled</span>';
      if (att) {
        if (att.status === 'Present') statusBadge = '<span class="badge badge-success">Present</span>';
        else if (att.status === 'Absent') statusBadge = '<span class="badge badge-danger">Absent</span>';
        else if (att.status === 'Late') statusBadge = '<span class="badge badge-warning">Late</span>';
        else if (att.status === 'Excused') statusBadge = '<span class="badge badge-indigo">Excused</span>';
      } else if (cls.status === 'completed') {
        statusBadge = '<span class="badge badge-success">Completed</span>';
      }

      const extraBadge = cls.isExtra ? '<span class="badge badge-purple ml-1">Extra Class</span>' : '';

      return `
        <div class="schedule-timeline-item">
          <div class="timeline-time">${cls.startTime} - ${cls.endTime}</div>
          <div class="timeline-student-info">
            <h5 class="cursor-pointer" onclick="window.TLStudents.openProfile('${cls.studentId}')">
              ${cls.studentName} ${extraBadge}
            </h5>
            <p>${cls.subject} • ${cls.mode === 'online' ? 'Online' : 'In-Person'} (${cls.venue || "Tutor's Studio"})</p>
          </div>
          <div class="timeline-action flex-wrap-gap">
            ${statusBadge}
            <button class="btn btn-outline btn-xs" onclick="window.TLAttendance.openAttendanceForClass('${cls.id}')" title="Mark / Edit Attendance">
              Mark Attendance
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  // 3. Render Monthly Collection Chart (Clean SVG Bar Chart)
  function renderMonthlyChart() {
    const container = document.getElementById('dash-collection-chart-container');
    if (!container) return;

    // Build data for the past 4 months dynamically
    const months = [];
    const now = new Date();
    for (let i = 3; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({
        key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`,
        label: d.toLocaleString('default', { month: 'short' }),
        fees: 0,
        paid: 0
      });
    }

    // Populate actual data from payments and student ledgers
    const payments = window.TLStore.getPayments();
    payments.forEach(p => {
      const pMonth = p.date.substring(0, 7);
      const mObj = months.find(m => m.key === pMonth);
      if (mObj) {
        mObj.paid += Number(p.amount) || 0;
      }
    });

    const students = window.TLStore.getStudents();
    students.forEach(s => {
      const ledger = window.TLStore.calculateStudentLedger(s.id);
      ledger.entries.forEach(entry => {
        const eMonth = entry.date.substring(0, 7);
        const mObj = months.find(m => m.key === eMonth);
        if (mObj) {
          mObj.fees += Number(entry.amount) || 0;
        }
      });
    });

    const maxVal = Math.max(...months.map(m => Math.max(m.fees, m.paid)), 8000);

    const svgWidth = 460;
    const svgHeight = 220;
    const chartPadding = { top: 25, right: 20, bottom: 40, left: 55 };
    const chartW = svgWidth - chartPadding.left - chartPadding.right;
    const chartH = svgHeight - chartPadding.top - chartPadding.bottom;
    const barGroupWidth = chartW / months.length;
    const barWidth = 22;

    const barsHtml = months.map((m, idx) => {
      const groupX = chartPadding.left + idx * barGroupWidth + (barGroupWidth - barWidth * 2 - 8) / 2;
      const feesH = Math.max(4, (m.fees / maxVal) * chartH);
      const paidH = Math.max(4, (m.paid / maxVal) * chartH);
      const feesY = chartPadding.top + chartH - feesH;
      const paidY = chartPadding.top + chartH - paidH;

      return `
        <!-- Fees Expected Bar -->
        <rect x="${groupX}" y="${feesY}" width="${barWidth}" height="${feesH}" rx="4" fill="#818cf8" opacity="0.85">
          <title>${m.label} Expected Fees: ${window.TLStore.formatCurrency(m.fees)}</title>
        </rect>
        <text x="${groupX + barWidth / 2}" y="${feesY - 6}" font-size="9" fill="#6366f1" text-anchor="middle" font-weight="600">
          ${m.fees > 0 ? (m.fees >= 1000 ? (m.fees/1000).toFixed(1)+'k' : m.fees) : ''}
        </text>

        <!-- Payments Received Bar -->
        <rect x="${groupX + barWidth + 6}" y="${paidY}" width="${barWidth}" height="${paidH}" rx="4" fill="#10b981">
          <title>${m.label} Payments Received: ${window.TLStore.formatCurrency(m.paid)}</title>
        </rect>
        <text x="${groupX + barWidth + 6 + barWidth / 2}" y="${paidY - 6}" font-size="9" fill="#059669" text-anchor="middle" font-weight="600">
          ${m.paid > 0 ? (m.paid >= 1000 ? (m.paid/1000).toFixed(1)+'k' : m.paid) : ''}
        </text>

        <!-- Month Label -->
        <text x="${groupX + barWidth + 3}" y="${chartPadding.top + chartH + 22}" font-size="11" fill="#64748b" text-anchor="middle" font-weight="600">
          ${m.label}
        </text>
      `;
    }).join('');

    container.innerHTML = `
      <div style="display:flex; justify-content: flex-end; gap: 16px; margin-bottom: 8px; font-size: 0.78rem;">
        <span style="display:inline-flex; align-items:center; gap:6px;">
          <span style="width:10px; height:10px; border-radius:2px; background:#818cf8; display:inline-block;"></span>
          Fees Generated
        </span>
        <span style="display:inline-flex; align-items:center; gap:6px;">
          <span style="width:10px; height:10px; border-radius:2px; background:#10b981; display:inline-block;"></span>
          Payments Collected
        </span>
      </div>
      <svg viewBox="0 0 ${svgWidth} ${svgHeight}" style="width: 100%; height: auto; overflow: visible;">
        <!-- Background Grid Lines -->
        <line x1="${chartPadding.left}" y1="${chartPadding.top}" x2="${svgWidth - chartPadding.right}" y2="${chartPadding.top}" stroke="#e2e8f0" stroke-dasharray="3,3" />
        <line x1="${chartPadding.left}" y1="${chartPadding.top + chartH / 2}" x2="${svgWidth - chartPadding.right}" y2="${chartPadding.top + chartH / 2}" stroke="#e2e8f0" stroke-dasharray="3,3" />
        <line x1="${chartPadding.left}" y1="${chartPadding.top + chartH}" x2="${svgWidth - chartPadding.right}" y2="${chartPadding.top + chartH}" stroke="#cbd5e1" stroke-width="1.5" />

        <!-- Y Axis Ticks -->
        <text x="${chartPadding.left - 8}" y="${chartPadding.top + 4}" font-size="10" fill="#94a3b8" text-anchor="end">
          ${window.TLStore.formatCurrency(maxVal)}
        </text>
        <text x="${chartPadding.left - 8}" y="${chartPadding.top + chartH / 2 + 4}" font-size="10" fill="#94a3b8" text-anchor="end">
          ${window.TLStore.formatCurrency(Math.round(maxVal / 2))}
        </text>
        <text x="${chartPadding.left - 8}" y="${chartPadding.top + chartH + 4}" font-size="10" fill="#94a3b8" text-anchor="end">
          0
        </text>

        ${barsHtml}
      </svg>
    `;
  }

  // 4. Render Students with Pending or Overdue Payments Table
  function renderPendingDues() {
    const tbody = document.getElementById('dash-pending-dues-tbody');
    if (!tbody) return;

    const students = window.TLStore.getStudents();
    const duesList = [];

    students.forEach(s => {
      const ledger = window.TLStore.calculateStudentLedger(s.id);
      if (ledger.balance > 0) {
        duesList.push({
          student: s,
          ledger: ledger
        });
      }
    });

    if (duesList.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6" class="text-center text-muted p-4">
            All student fee accounts are fully settled. Outstanding balance is 0.
          </td>
        </tr>
      `;
      return;
    }

    // Sort overdue first, then highest balance
    duesList.sort((a, b) => {
      if (a.ledger.isOverdue && !b.ledger.isOverdue) return -1;
      if (!a.ledger.isOverdue && b.ledger.isOverdue) return 1;
      return b.ledger.balance - a.ledger.balance;
    });

    tbody.innerHTML = duesList.slice(0, 5).map(item => {
      const s = item.student;
      const l = item.ledger;

      let statusBadge = '<span class="badge badge-warning">Pending</span>';
      if (l.isOverdue) {
        statusBadge = '<span class="badge badge-danger">Overdue</span>';
      } else if (l.totalPaid > 0) {
        statusBadge = '<span class="badge badge-warning">Partially Paid</span>';
      }

      return `
        <tr>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${s.id}')">
              ${s.name}
            </a>
            <div class="text-muted font-size-12">${s.id} • ${s.grade}</div>
          </td>
          <td>
            ${s.billingMethod === 'per_class' ? 'Per-Class' : 'Monthly Fixed'}
            <div class="text-muted font-size-11">Due day: ${s.dueDay}th of month</div>
          </td>
          <td class="font-weight-700 ${l.isOverdue ? 'text-danger' : 'text-warning'}">
            ${window.TLStore.formatCurrency(l.balance)}
          </td>
          <td class="font-size-12 text-muted">
            ${l.nextDueDate || '—'}
          </td>
          <td>${statusBadge}</td>
          <td>
            <button class="btn btn-primary btn-xs" onclick="window.TLPayments.openRecordPaymentModal('${s.id}')">
              Record Pay
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // 5. Render Recent Payments Table
  function renderRecentPayments() {
    const tbody = document.getElementById('dash-recent-payments-tbody');
    if (!tbody) return;

    const payments = window.TLStore.getPayments().slice(-5).reverse();

    if (payments.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" class="text-center text-muted p-4">
            No payments recorded yet.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = payments.map(p => {
      return `
        <tr>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${p.studentId}')">
              ${p.studentName}
            </a>
          </td>
          <td class="font-weight-700 text-success">
            ${window.TLStore.formatCurrency(p.amount)}
          </td>
          <td class="font-size-12 text-muted">${p.date}</td>
          <td>
            <span class="badge badge-indigo font-size-11">${p.method}</span>
          </td>
          <td>
            <button class="btn btn-outline btn-xs" onclick="window.TLPayments.viewReceipt('${p.id}')">
              View Receipt
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // 6. Render Upcoming Classes (Next 7 Days)
  function renderUpcomingClasses() {
    const tbody = document.getElementById('dash-upcoming-classes-tbody');
    if (!tbody) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const nextWeekDate = new Date();
    nextWeekDate.setDate(nextWeekDate.getDate() + 7);
    const nextWeekStr = nextWeekDate.toISOString().split('T')[0];

    const classes = window.TLStore.getClasses();
    const upcoming = classes.filter(c => c.date >= todayStr && c.date <= nextWeekStr && c.status !== 'cancelled')
      .sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime));

    if (upcoming.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6" class="text-center text-muted p-4">
            No upcoming classes in the next 7 days.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = upcoming.map(c => {
      const typeBadge = c.isExtra
        ? '<span class="badge badge-purple">Extra Class</span>'
        : '<span class="badge badge-indigo">Regular</span>';

      return `
        <tr>
          <td>
            <span class="font-weight-600">${c.date}</span>
            <div class="text-muted font-size-12">${c.startTime} - ${c.endTime}</div>
          </td>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${c.studentId}')">
              ${c.studentName}
            </a>
          </td>
          <td>${c.subject}</td>
          <td>${typeBadge}</td>
          <td>
            <span class="font-size-12">${c.mode === 'online' ? 'Online' : 'In-Person'}</span>
            <div class="text-muted font-size-11">${c.venue || '—'}</div>
          </td>
          <td>
            <div class="flex-wrap-gap">
              <button class="btn btn-outline btn-xs" onclick="window.TLAttendance.openAttendanceForClass('${c.id}')">
                Attendance
              </button>
              <button class="btn btn-outline btn-xs" onclick="window.TLSchedule.openScheduleModal('${c.id}')">
                Edit
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // Expose Dashboard Controller
  window.TLDashboard = {
    init: initDashboard,
    refresh: initDashboard
  };

  // Subscribe to store updates
  window.TLStore.subscribe(() => {
    initDashboard();
  });
})();
