/**
 * TUTOR LEDGER — Settings Controller
 * Handles tutor profile updates, currency preferences, billing and cancellation policies,
 * JSON database backups, file restoration, and slate resets.
 */

(function () {
  'use strict';

  function initSettings() {
    setupEventListeners();
    loadCurrentSettingsIntoForm();
  }

  function setupEventListeners() {
    // Save Settings Button
    document.getElementById('btn-save-settings')?.addEventListener('click', handleSaveSettings);

    // Backup JSON
    document.getElementById('btn-backup-json')?.addEventListener('click', handleBackupJSON);

    // Import JSON File
    const importInput = document.getElementById('input-import-json');
    if (importInput) {
      importInput.addEventListener('change', handleImportJSON);
    }

    // Reload Demo Records
    document.getElementById('btn-load-demo-data')?.addEventListener('click', () => {
      if (confirm('Reload realistic sample records into Tutor Ledger? Any unsaved edits to sample data will be restored.')) {
        window.TLStore.resetToSeed();
        window.TLApp.showToast('Demo data reloaded successfully!', 'success');
        loadCurrentSettingsIntoForm();
      }
    });

    // Quick Reset Demo Data button on sidebar footer
    document.getElementById('btn-quick-sample-data')?.addEventListener('click', () => {
      if (confirm('Reset Tutor Ledger to fresh demo data?')) {
        window.TLStore.resetToSeed();
        window.TLApp.showToast('Demo data refreshed!', 'success');
        loadCurrentSettingsIntoForm();
      }
    });

    // Clear All Data
    document.getElementById('btn-clear-all-data')?.addEventListener('click', () => {
      if (confirm('Warning: This will delete ALL student records, schedules, attendance, and payment history! Are you sure you want to start with a blank slate?')) {
        window.TLStore.clearAll();
        window.TLApp.showToast('All records cleared. Blank slate ready.', 'warning');
      }
    });
  }

  function loadCurrentSettingsIntoForm() {
    const s = window.TLStore.getSettings();

    const nameInput = document.getElementById('set-tutor-name');
    const titleInput = document.getElementById('set-tutor-title');
    const phoneInput = document.getElementById('set-tutor-phone');
    const emailInput = document.getElementById('set-tutor-email');
    const addrInput = document.getElementById('set-tutor-address');
    const currSelect = document.getElementById('set-currency');
    const billSelect = document.getElementById('set-default-billing');
    const durInput = document.getElementById('set-default-duration');
    const chgAbsent = document.getElementById('set-charge-absent');
    const chgCancel = document.getElementById('set-charge-cancelled');

    if (nameInput) nameInput.value = s.tutorName || '';
    if (titleInput) titleInput.value = s.tutorTitle || '';
    if (phoneInput) phoneInput.value = s.phone || '';
    if (emailInput) emailInput.value = s.email || '';
    if (addrInput) addrInput.value = s.address || '';
    if (currSelect) currSelect.value = s.currency || 'INR';
    if (billSelect) billSelect.value = s.defaultBilling || 'per_class';
    if (durInput) durInput.value = s.defaultDuration || 60;
    if (chgAbsent) chgAbsent.checked = !!s.chargeAbsent;
    if (chgCancel) chgCancel.checked = !!s.chargeCancelled;

    // Update sidebar tutor name & avatar
    const sideName = document.getElementById('sidebar-tutor-name');
    const sideAvatar = document.getElementById('sidebar-avatar');
    if (sideName && s.tutorName) sideName.textContent = s.tutorName;
    if (sideAvatar && s.tutorName) {
      sideAvatar.textContent = s.tutorName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
    }

    // Update header currency badge
    const headerCurr = document.getElementById('header-currency-badge');
    if (headerCurr) {
      headerCurr.innerHTML = `<span class="currency-symbol">${window.TLStore.getCurrencySymbol()}</span> ${s.currency || 'INR'}`;
    }
  }

  function handleSaveSettings(e) {
    if (e) e.preventDefault();

    const tutorName = document.getElementById('set-tutor-name')?.value.trim() || 'Tutor';
    const tutorTitle = document.getElementById('set-tutor-title')?.value.trim() || '';
    const phone = document.getElementById('set-tutor-phone')?.value.trim() || '';
    const email = document.getElementById('set-tutor-email')?.value.trim() || '';
    const address = document.getElementById('set-tutor-address')?.value.trim() || '';
    const currency = document.getElementById('set-currency')?.value || 'INR';
    const defaultBilling = document.getElementById('set-default-billing')?.value || 'per_class';
    const defaultDuration = Number(document.getElementById('set-default-duration')?.value) || 60;
    const chargeAbsent = document.getElementById('set-charge-absent')?.checked;
    const chargeCancelled = document.getElementById('set-charge-cancelled')?.checked;

    window.TLStore.updateSettings({
      tutorName,
      tutorTitle,
      phone,
      email,
      address,
      currency,
      defaultBilling,
      defaultDuration,
      chargeAbsent,
      chargeCancelled
    });

    loadCurrentSettingsIntoForm();
    window.TLApp.showToast('Settings & billing preferences saved successfully!', 'success');
  }

  // Backup store to JSON file
  function handleBackupJSON() {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(window.TLStore.data, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute('href', dataStr);
    dlAnchor.setAttribute('download', `TUTOR_LEDGER_Backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();
    window.TLApp.showToast('Full JSON backup downloaded!', 'success');
  }

  // Import JSON file into store
  function handleImportJSON(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (event) {
      try {
        const parsed = JSON.parse(event.target.result);
        if (parsed && parsed.students && parsed.classes) {
          window.TLStore.data = parsed;
          window.TLStore.persist();
          window.TLStore.notify();
          loadCurrentSettingsIntoForm();
          window.TLApp.showToast('Database backup restored successfully!', 'success');
        } else {
          window.TLApp.showToast('Invalid Tutor Ledger backup file format.', 'danger');
        }
      } catch (err) {
        console.error('Import JSON error:', err);
        window.TLApp.showToast('Failed to parse JSON backup file.', 'danger');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  // Expose Settings Controller
  window.TLSettings = {
    init: initSettings,
    refresh: loadCurrentSettingsIntoForm
  };
})();
