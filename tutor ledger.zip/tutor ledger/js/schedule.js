/**
 * TUTOR LEDGER — Class Schedule & Calendar Controller
 * Handles Month, Week, Day, and List calendar views, class scheduling,
 * overlap/conflict detection, performance-based extra classes, and rescheduling history.
 */

(function () {
  'use strict';

  let currentCalDate = new Date(); // Active viewing date
  let currentView = 'month'; // 'month' | 'week' | 'day' | 'list'

  function initSchedule() {
    setupEventListeners();
    populateStudentSelect();
    renderCalendar();
  }

  function setupEventListeners() {
    // Navigation controls
    document.getElementById('cal-btn-prev')?.addEventListener('click', () => {
      navigateCalendar(-1);
    });

    document.getElementById('cal-btn-next')?.addEventListener('click', () => {
      navigateCalendar(1);
    });

    document.getElementById('cal-btn-today')?.addEventListener('click', () => {
      currentCalDate = new Date();
      renderCalendar();
    });

    // View toggles
    const viewButtons = document.querySelectorAll('.cal-view-toggles .btn-group-item');
    viewButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.getAttribute('data-view');
        currentView = view;
        viewButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderCalendar();
      });
    });

    // Open Schedule Modal Button
    document.getElementById('btn-open-schedule-modal')?.addEventListener('click', () => {
      openScheduleModal();
    });

    // Student select auto-fill subject
    const studentSelect = document.getElementById('sch-student');
    if (studentSelect) {
      studentSelect.addEventListener('change', () => {
        const studentId = studentSelect.value;
        const student = window.TLStore.getStudentById(studentId);
        if (student) {
          const subInput = document.getElementById('sch-subject');
          if (subInput && !subInput.value) {
            subInput.value = student.subjects.split(',')[0].trim();
          }
        }
      });
    }

    // Extra Class Checkbox Toggle
    const extraCheckbox = document.getElementById('sch-is-extra');
    const extraBox = document.getElementById('extra-class-details');
    if (extraCheckbox && extraBox) {
      extraCheckbox.addEventListener('change', () => {
        extraBox.style.display = extraCheckbox.checked ? 'block' : 'none';
        const reasonInput = document.getElementById('sch-extra-reason');
        if (reasonInput) reasonInput.required = extraCheckbox.checked;
      });
    }

    // Conflict Check on Time/Date change in modal
    ['sch-date', 'sch-start-time', 'sch-end-time'].forEach(id => {
      document.getElementById(id)?.addEventListener('change', checkModalConflict);
    });

    // Schedule Form Submit
    document.getElementById('form-schedule')?.addEventListener('submit', handleScheduleSubmit);
  }

  function populateStudentSelect(selectedStudentId = null) {
    const select = document.getElementById('sch-student');
    if (!select) return;

    const students = window.TLStore.getStudents().filter(s => s.status === 'active');
    select.innerHTML = '<option value="">-- Choose student --</option>' +
      students.map(s => `
        <option value="${s.id}" ${s.id === selectedStudentId ? 'selected' : ''}>
          ${s.name} (${s.grade} • ${s.id})
        </option>
      `).join('');
  }

  function navigateCalendar(delta) {
    if (currentView === 'month') {
      currentCalDate.setMonth(currentCalDate.getMonth() + delta);
    } else if (currentView === 'week') {
      currentCalDate.setDate(currentCalDate.getDate() + (delta * 7));
    } else {
      currentCalDate.setDate(currentCalDate.getDate() + delta);
    }
    renderCalendar();
  }

  // Render Calendar according to current active view
  function renderCalendar() {
    const label = document.getElementById('cal-current-label');
    const monthView = document.getElementById('calendar-month-view');
    const timeGridView = document.getElementById('calendar-time-grid-view');
    const listView = document.getElementById('calendar-list-view');

    // Update Header Label
    const options = { month: 'long', year: 'numeric' };
    if (currentView === 'day') {
      options.weekday = 'short';
      options.day = 'numeric';
    }
    if (label) label.textContent = currentCalDate.toLocaleDateString('en-US', options);

    if (currentView === 'month') {
      if (monthView) monthView.style.display = 'grid';
      if (timeGridView) timeGridView.style.display = 'none';
      if (listView) listView.style.display = 'none';
      renderMonthView();
    } else if (currentView === 'list') {
      if (monthView) monthView.style.display = 'none';
      if (timeGridView) timeGridView.style.display = 'none';
      if (listView) listView.style.display = 'block';
      renderListView();
    } else {
      // Week or Day View
      if (monthView) monthView.style.display = 'none';
      if (timeGridView) timeGridView.style.display = 'block';
      if (listView) listView.style.display = 'none';
      renderTimeGridView();
    }
  }

  // 1. Month View Renderer
  function renderMonthView() {
    const grid = document.getElementById('calendar-month-view');
    if (!grid) return;

    grid.innerHTML = '';

    // Day of week headers
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    daysOfWeek.forEach(day => {
      const headerCell = document.createElement('div');
      headerCell.className = 'cal-day-header';
      headerCell.textContent = day;
      grid.appendChild(headerCell);
    });

    const year = currentCalDate.getFullYear();
    const month = currentCalDate.getMonth();

    const firstDayIndex = new Date(year, month, 1).getDay();
    const totalDaysInMonth = new Date(year, month + 1, 0).getDate();
    const prevMonthDays = new Date(year, month, 0).getDate();

    const todayStr = new Date().toISOString().split('T')[0];
    const allClasses = window.TLStore.getClasses();

    // 42 cells grid (6 rows of 7)
    for (let i = 0; i < 42; i++) {
      const cell = document.createElement('div');
      cell.className = 'cal-day-cell';

      let cellDateStr = '';
      let dayNumber = 0;
      let isCurrentMonth = true;

      if (i < firstDayIndex) {
        // Previous month days
        dayNumber = prevMonthDays - firstDayIndex + i + 1;
        cell.classList.add('other-month');
        isCurrentMonth = false;
        const prevMonth = month === 0 ? 11 : month - 1;
        const prevYear = month === 0 ? year - 1 : year;
        cellDateStr = `${prevYear}-${String(prevMonth + 1).padStart(2, '0')}-${String(dayNumber).padStart(2, '0')}`;
      } else if (i >= firstDayIndex + totalDaysInMonth) {
        // Next month days
        dayNumber = i - (firstDayIndex + totalDaysInMonth) + 1;
        cell.classList.add('other-month');
        isCurrentMonth = false;
        const nextMonth = month === 11 ? 0 : month + 1;
        const nextYear = month === 11 ? year + 1 : year;
        cellDateStr = `${nextYear}-${String(nextMonth + 1).padStart(2, '0')}-${String(dayNumber).padStart(2, '0')}`;
      } else {
        // Current month days
        dayNumber = i - firstDayIndex + 1;
        cellDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNumber).padStart(2, '0')}`;
      }

      if (cellDateStr === todayStr) {
        cell.classList.add('is-today');
      }

      const numEl = document.createElement('div');
      numEl.className = 'cal-day-num';
      numEl.textContent = dayNumber;
      cell.appendChild(numEl);

      // Classes on this day
      const dayClasses = allClasses.filter(c => c.date === cellDateStr && c.status !== 'cancelled')
        .sort((a, b) => a.startTime.localeCompare(b.startTime));

      dayClasses.forEach(cls => {
        const pill = document.createElement('div');
        pill.className = `cal-event-pill ${cls.isExtra ? 'extra-class' : ''}`;
        pill.title = `${cls.startTime} - ${cls.endTime}: ${cls.studentName} (${cls.subject})${cls.isExtra ? ' [Extra Class]' : ''}`;
        pill.textContent = `${cls.startTime} ${cls.studentName} (${cls.subject.substring(0, 4)})`;
        pill.addEventListener('click', (e) => {
          e.stopPropagation();
          openScheduleModal(cls.id);
        });
        cell.appendChild(pill);
      });

      // Click on day to schedule class for that date
      cell.addEventListener('click', () => {
        openScheduleModal(null, cellDateStr);
      });

      grid.appendChild(cell);
    }
  }

  // 2. Time Grid View (Week / Day)
  function renderTimeGridView() {
    const container = document.getElementById('calendar-time-grid-view');
    if (!container) return;

    const allClasses = window.TLStore.getClasses();

    if (currentView === 'day') {
      const dateStr = currentCalDate.toISOString().split('T')[0];
      const dayClasses = allClasses.filter(c => c.date === dateStr && c.status !== 'cancelled')
        .sort((a, b) => a.startTime.localeCompare(b.startTime));

      container.innerHTML = `
        <div style="padding: 20px;">
          <h4 style="font-size: 1.05rem; font-weight: 700; margin-bottom: 16px;">
            Schedule for ${currentCalDate.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </h4>
          ${dayClasses.length === 0 ? '<p class="text-muted">No classes scheduled for this date.</p>' : ''}
          <div style="display:flex; flex-direction:column; gap: 10px;">
            ${dayClasses.map(c => `
              <div class="card p-3" style="border-left: 4px solid ${c.isExtra ? '#9333ea' : '#4f46e5'};">
                <div class="flex-between">
                  <div>
                    <span class="badge ${c.isExtra ? 'badge-purple' : 'badge-indigo'}">${c.startTime} - ${c.endTime}</span>
                    ${c.isExtra ? '<span class="badge badge-purple ml-1">Extra Academic Support</span>' : ''}
                    <h5 class="font-size-15 font-weight-700 mt-1 cursor-pointer" onclick="window.TLStudents.openProfile('${c.studentId}')">
                      ${c.studentName} — ${c.subject}
                    </h5>
                    <p class="font-size-12 text-muted">${c.mode === 'online' ? 'Online' : 'In-Person'} • ${c.venue || 'Tutor Studio'}</p>
                    ${c.isExtra && c.extraReason ? `<p class="font-size-12 text-purple font-weight-500 mt-1">Reason: ${c.extraReason}</p>` : ''}
                  </div>
                  <div class="flex-wrap-gap">
                    <button class="btn btn-outline btn-xs" onclick="window.TLAttendance.openAttendanceForClass('${c.id}')">Attendance</button>
                    <button class="btn btn-primary btn-xs" onclick="window.TLSchedule.openScheduleModal('${c.id}')">Edit</button>
                  </div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    } else {
      // Week view
      const startOfWeek = new Date(currentCalDate);
      startOfWeek.setDate(currentCalDate.getDate() - currentCalDate.getDay()); // Sunday

      const weekDays = [];
      for (let i = 0; i < 7; i++) {
        const d = new Date(startOfWeek);
        d.setDate(startOfWeek.getDate() + i);
        weekDays.push(d);
      }

      container.innerHTML = `
        <div class="table-responsive">
          <table class="data-table" style="table-layout: fixed;">
            <thead>
              <tr>
                ${weekDays.map(d => `
                  <th style="text-align:center; padding: 10px;">
                    <div>${d.toLocaleDateString('en-US', { weekday: 'short' })}</div>
                    <div style="font-size: 1.1rem; font-weight: 700; color: ${d.toISOString().split('T')[0] === new Date().toISOString().split('T')[0] ? 'var(--primary)' : 'inherit'};">
                      ${d.getDate()}
                    </div>
                  </th>
                `).join('')}
              </tr>
            </thead>
            <tbody>
              <tr>
                ${weekDays.map(d => {
                  const dStr = d.toISOString().split('T')[0];
                  const classesOnDay = allClasses.filter(c => c.date === dStr && c.status !== 'cancelled')
                    .sort((a, b) => a.startTime.localeCompare(b.startTime));

                  return `
                    <td style="vertical-align: top; height: 180px; padding: 8px; border-right: 1px solid var(--border-color);">
                      ${classesOnDay.map(c => `
                        <div class="cal-event-pill ${c.isExtra ? 'extra-class' : ''}" onclick="window.TLSchedule.openScheduleModal('${c.id}')">
                          <strong>${c.startTime}</strong> ${c.studentName}
                        </div>
                      `).join('')}
                      <button class="btn btn-outline btn-xs btn-full mt-2" onclick="window.TLSchedule.openScheduleModal(null, '${dStr}')">+ Class</button>
                    </td>
                  `;
                }).join('')}
              </tr>
            </tbody>
          </table>
        </div>
      `;
    }
  }

  // 3. List View Renderer
  function renderListView() {
    const tbody = document.getElementById('cal-list-view-tbody');
    if (!tbody) return;

    const allClasses = window.TLStore.getClasses()
      .sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));

    if (allClasses.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted p-4">No scheduled classes found.</td></tr>';
      return;
    }

    tbody.innerHTML = allClasses.map(cls => {
      const typeBadge = cls.isExtra
        ? '<span class="badge badge-purple">Extra Class</span>'
        : '<span class="badge badge-indigo">Regular</span>';

      const att = window.TLStore.getAttendanceByClassId(cls.id);
      let statusBadge = `<span class="badge ${cls.status === 'completed' ? 'badge-success' : 'badge-neutral'}">${cls.status}</span>`;
      if (att) {
        statusBadge = `<span class="badge ${att.status === 'Present' ? 'badge-success' : 'badge-warning'}">${att.status}</span>`;
      }

      return `
        <tr>
          <td><span class="font-weight-600">${cls.date}</span></td>
          <td>${cls.startTime} - ${cls.endTime}</td>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${cls.studentId}')">
              ${cls.studentName}
            </a>
          </td>
          <td>${cls.subject}</td>
          <td>
            ${typeBadge}
            ${cls.isExtra && cls.extraReason ? `<div class="font-size-11 text-muted">${cls.extraReason}</div>` : ''}
          </td>
          <td>${cls.mode === 'online' ? 'Online' : 'In-Person'} (${cls.venue || 'Studio'})</td>
          <td>${statusBadge}</td>
          <td>
            <div class="flex-wrap-gap">
              <button class="btn btn-outline btn-xs" onclick="window.TLAttendance.openAttendanceForClass('${cls.id}')">
                Attendance
              </button>
              <button class="btn btn-primary btn-xs" onclick="window.TLSchedule.openScheduleModal('${cls.id}')">
                Edit
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // 4. Open Schedule Modal (Create or Reschedule)
  function openScheduleModal(classId = null, defaultDate = null, defaultStudentId = null) {
    const form = document.getElementById('form-schedule');
    const title = document.getElementById('modal-schedule-title');
    const idInput = document.getElementById('schedule-form-id');
    const conflictAlert = document.getElementById('modal-conflict-warning');
    if (!form) return;

    form.reset();
    populateStudentSelect(defaultStudentId);
    if (conflictAlert) conflictAlert.style.display = 'none';

    const extraBox = document.getElementById('extra-class-details');
    if (extraBox) extraBox.style.display = 'none';

    if (classId) {
      const cls = window.TLStore.getClassById(classId);
      if (!cls) return;

      if (title) title.textContent = `Edit / Reschedule Class: ${cls.studentName}`;
      if (idInput) idInput.value = cls.id;

      document.getElementById('sch-student').value = cls.studentId;
      document.getElementById('sch-subject').value = cls.subject;
      document.getElementById('sch-date').value = cls.date;
      document.getElementById('sch-start-time').value = cls.startTime;
      document.getElementById('sch-end-time').value = cls.endTime;
      document.getElementById('sch-mode').value = cls.mode;
      document.getElementById('sch-venue').value = cls.venue || '';
      document.getElementById('sch-notes').value = cls.notes || '';

      const isExtraCb = document.getElementById('sch-is-extra');
      if (isExtraCb) {
        isExtraCb.checked = !!cls.isExtra;
        if (cls.isExtra) {
          if (extraBox) extraBox.style.display = 'block';
          document.getElementById('sch-extra-reason').value = cls.extraReason || '';
          document.getElementById('sch-extra-chargeable').checked = cls.extraChargeable !== false;
        }
      }
    } else {
      if (title) title.textContent = 'Schedule a Class';
      if (idInput) idInput.value = '';

      const dateToSet = defaultDate || new Date().toISOString().split('T')[0];
      document.getElementById('sch-date').value = dateToSet;
      document.getElementById('sch-start-time').value = '16:00';
      document.getElementById('sch-end-time').value = '17:00';
      document.getElementById('sch-mode').value = 'in_person';
      document.getElementById('sch-venue').value = "Tutor's Studio";
    }

    window.TLApp.openModal('modal-schedule');
  }

  // 5. Conflict Checker for Same Tutor Time Overlap
  function checkModalConflict() {
    const classId = document.getElementById('schedule-form-id')?.value || null;
    const date = document.getElementById('sch-date')?.value;
    const startTime = document.getElementById('sch-start-time')?.value;
    const endTime = document.getElementById('sch-end-time')?.value;
    const conflictAlert = document.getElementById('modal-conflict-warning');

    if (!date || !startTime || !endTime || !conflictAlert) return;

    const conflict = window.TLStore.checkClassConflict(date, startTime, endTime, classId);
    if (conflict) {
      conflictAlert.style.display = 'block';
      conflictAlert.innerHTML = `
        <strong>Time Conflict Warning:</strong> Overlaps with scheduled class for <strong>${conflict.studentName}</strong> (${conflict.startTime} - ${conflict.endTime}) on this date.
      `;
    } else {
      conflictAlert.style.display = 'none';
    }
  }

  // 6. Handle Schedule Submit
  function handleScheduleSubmit(e) {
    e.preventDefault();

    const classId = document.getElementById('schedule-form-id').value;
    const studentId = document.getElementById('sch-student').value;
    const subject = document.getElementById('sch-subject').value.trim();
    const date = document.getElementById('sch-date').value;
    const startTime = document.getElementById('sch-start-time').value;
    const endTime = document.getElementById('sch-end-time').value;
    const mode = document.getElementById('sch-mode').value;
    const venue = document.getElementById('sch-venue').value.trim();
    const isExtra = document.getElementById('sch-is-extra').checked;
    const extraReason = isExtra ? document.getElementById('sch-extra-reason').value.trim() : '';
    const extraChargeable = isExtra ? document.getElementById('sch-extra-chargeable').checked : true;
    const notes = document.getElementById('sch-notes').value.trim();

    if (!studentId || !subject || !date || !startTime || !endTime) {
      window.TLApp.showToast('Please fill all required class schedule fields.', 'warning');
      return;
    }

    if (endTime <= startTime) {
      window.TLApp.showToast('End time must be after start time.', 'warning');
      return;
    }

    const student = window.TLStore.getStudentById(studentId);
    const studentName = student ? student.name : 'Student';

    const saved = window.TLStore.saveClass({
      id: classId || undefined,
      studentId,
      studentName,
      subject,
      date,
      startTime,
      endTime,
      mode,
      venue,
      isExtra,
      extraReason,
      extraChargeable,
      notes
    });

    window.TLApp.closeModal('modal-schedule');
    window.TLApp.showToast(`Class successfully scheduled for ${studentName} on ${date}!`, 'success');
    renderCalendar();
  }

  // Expose Schedule Controller
  window.TLSchedule = {
    init: initSchedule,
    refresh: renderCalendar,
    openScheduleModal: openScheduleModal
  };

  window.TLStore.subscribe(() => {
    populateStudentSelect();
    renderCalendar();
  });
})();
