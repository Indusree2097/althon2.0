/**
 * TUTOR LEDGER — Main Application Orchestrator & Router
 * Manages SPA page navigation, responsive sidebar drawer, global instant search,
 * in-app notification center, toast alerts, and modal lifecycle.
 */

(function () {
  'use strict';

  // 1. Navigation & Routing
  function initRouting() {
    window.addEventListener('hashchange', handleHashChange);
    // Initial route
    handleHashChange();
  }

  function handleHashChange() {
    const rawHash = window.location.hash.replace('#', '') || 'dashboard';
    navigateTo(rawHash);
  }

  function navigateTo(pageId) {
    // Validate page exists
    const validPages = ['dashboard', 'students', 'schedule', 'attendance', 'payments', 'notifications', 'reports', 'settings'];
    const activePage = validPages.includes(pageId) ? pageId : 'dashboard';

    // Update Page Sections
    document.querySelectorAll('.page-section').forEach(sec => {
      sec.classList.remove('active');
    });
    const targetSection = document.getElementById(`page-${activePage}`);
    if (targetSection) targetSection.classList.add('active');

    // Update Sidebar Nav Links
    document.querySelectorAll('.sidebar-nav .nav-item').forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('data-page') === activePage) {
        link.classList.add('active');
      }
    });

    // Update Top Header Heading
    const headingEl = document.getElementById('page-main-heading');
    if (headingEl) {
      headingEl.textContent = formatPageTitle(activePage);
    }

    // Close mobile sidebar if open
    closeMobileSidebar();

    // Trigger page-specific refresh
    if (activePage === 'dashboard' && window.TLDashboard) window.TLDashboard.refresh();
    else if (activePage === 'students' && window.TLStudents) window.TLStudents.refresh();
    else if (activePage === 'schedule' && window.TLSchedule) window.TLSchedule.refresh();
    else if (activePage === 'attendance' && window.TLAttendance) window.TLAttendance.refresh();
    else if (activePage === 'payments' && window.TLPayments) window.TLPayments.refresh();
    else if (activePage === 'notifications') renderNotificationsPage();
    else if (activePage === 'reports' && window.TLReports) window.TLReports.refresh();
    else if (activePage === 'settings' && window.TLSettings) window.TLSettings.refresh();

    // Scroll to top of content
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function formatPageTitle(pageId) {
    switch (pageId) {
      case 'dashboard': return 'Dashboard';
      case 'students': return 'Student Directory';
      case 'schedule': return 'Class Schedule & Calendar';
      case 'attendance': return 'Attendance Tracker';
      case 'payments': return 'Payments & Dues Ledger';
      case 'notifications': return 'Notifications Center';
      case 'reports': return 'Reports & Financial Analytics';
      case 'settings': return 'Settings & Preferences';
      default: return 'Tutor Ledger';
    }
  }

  // 2. Mobile Sidebar Drawer Controls
  function initMobileSidebar() {
    const toggleBtn = document.getElementById('sidebar-toggle-btn');
    const closeBtn = document.getElementById('sidebar-close-btn');
    const backdrop = document.getElementById('sidebar-backdrop');
    const sidebar = document.getElementById('sidebar');

    toggleBtn?.addEventListener('click', () => {
      sidebar?.classList.add('open');
      backdrop?.classList.add('show');
    });

    closeBtn?.addEventListener('click', closeMobileSidebar);
    backdrop?.addEventListener('click', closeMobileSidebar);
  }

  function closeMobileSidebar() {
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    sidebar?.classList.remove('open');
    backdrop?.classList.remove('show');
  }

  // 3. Header Date Display
  function initHeaderDate() {
    const dateEl = document.getElementById('header-date-badge');
    if (!dateEl) return;
    const now = new Date();
    dateEl.textContent = now.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  // 4. Global Instant Search
  function initGlobalSearch() {
    const input = document.getElementById('global-search-input');
    const resultsBox = document.getElementById('global-search-results');
    const clearBtn = document.getElementById('global-search-clear');

    if (!input || !resultsBox) return;

    input.addEventListener('input', () => {
      const q = input.value.trim().toLowerCase();

      if (q.length > 0) {
        if (clearBtn) clearBtn.style.display = 'block';
      } else {
        if (clearBtn) clearBtn.style.display = 'none';
        resultsBox.style.display = 'none';
        return;
      }

      const students = window.TLStore.getStudents();
      const matches = students.filter(s => {
        return (
          s.name.toLowerCase().includes(q) ||
          s.id.toLowerCase().includes(q) ||
          (s.phone && s.phone.toLowerCase().includes(q)) ||
          (s.subjects && s.subjects.toLowerCase().includes(q)) ||
          (s.grade && s.grade.toLowerCase().includes(q)) ||
          (s.parentName && s.parentName.toLowerCase().includes(q))
        );
      });

      if (matches.length === 0) {
        resultsBox.innerHTML = `
          <div style="padding: 14px; text-align: center; color: var(--text-muted); font-size: 0.82rem;">
            No students found matching "<strong>${q}</strong>"
          </div>
        `;
        resultsBox.style.display = 'block';
        return;
      }

      resultsBox.innerHTML = matches.map(s => {
        const ledger = window.TLStore.calculateStudentLedger(s.id);
        return `
          <div class="search-result-item" onclick="window.TLApp.selectSearchResult('${s.id}')">
            <div>
              <div style="font-weight: 700; font-size: 0.88rem; color: var(--text-main);">${s.name}</div>
              <div style="font-size: 0.75rem; color: var(--text-muted);">${s.id} • ${s.grade} • ${s.subjects}</div>
            </div>
            <div style="text-align: right;">
              <span class="badge ${ledger.balance === 0 ? 'badge-success' : 'badge-warning'}">
                ${ledger.balance === 0 ? 'Paid' : window.TLStore.formatCurrency(ledger.balance)}
              </span>
            </div>
          </div>
        `;
      }).join('');

      resultsBox.style.display = 'block';
    });

    clearBtn?.addEventListener('click', () => {
      input.value = '';
      clearBtn.style.display = 'none';
      resultsBox.style.display = 'none';
      input.focus();
    });

    // Close results when clicking outside
    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !resultsBox.contains(e.target)) {
        resultsBox.style.display = 'none';
      }
    });
  }

  function selectSearchResult(studentId) {
    const resultsBox = document.getElementById('global-search-results');
    const input = document.getElementById('global-search-input');
    if (resultsBox) resultsBox.style.display = 'none';
    if (input) input.value = '';

    window.TLStudents.openProfile(studentId);
  }

  // 5. Quick Actions Menu
  function initQuickActions() {
    const btn = document.getElementById('btn-header-quick-action');
    const menu = document.getElementById('quick-action-menu');

    btn?.addEventListener('click', (e) => {
      e.stopPropagation();
      menu?.classList.toggle('show');
    });

    // Menu Item clicks
    menu?.querySelectorAll('.dropdown-item').forEach(item => {
      item.addEventListener('click', () => {
        const action = item.getAttribute('data-action');
        menu.classList.remove('show');

        if (action === 'add-student') {
          window.TLStudents.openStudentFormModal();
        } else if (action === 'schedule-class') {
          window.TLSchedule.openScheduleModal();
        } else if (action === 'mark-attendance') {
          navigateTo('attendance');
        } else if (action === 'record-payment') {
          window.TLPayments.openRecordPaymentModal();
        }
      });
    });

    // Dashboard Banner Quick Actions
    document.getElementById('dash-btn-add-student')?.addEventListener('click', () => {
      window.TLStudents.openStudentFormModal();
    });

    document.getElementById('dash-btn-schedule')?.addEventListener('click', () => {
      window.TLSchedule.openScheduleModal();
    });

    document.getElementById('dash-btn-record-payment')?.addEventListener('click', () => {
      window.TLPayments.openRecordPaymentModal();
    });

    document.getElementById('dash-btn-quick-record-pay')?.addEventListener('click', () => {
      window.TLPayments.openRecordPaymentModal();
    });

    document.getElementById('dash-btn-schedule-new')?.addEventListener('click', () => {
      window.TLSchedule.openScheduleModal();
    });

    // KPI Cards Click to Navigate
    document.querySelectorAll('.kpi-card[data-navigate]').forEach(card => {
      card.addEventListener('click', () => {
        const target = card.getAttribute('data-navigate');
        if (target) navigateTo(target);
      });
    });
  }

  // 6. Notifications System
  function initNotifications() {
    const bellBtn = document.getElementById('header-bell-btn');
    const dropdown = document.getElementById('header-notifications-dropdown');
    const btnMarkAll = document.getElementById('btn-popover-mark-all-read');

    bellBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown?.classList.toggle('show');
      renderPopoverNotifications();
    });

    btnMarkAll?.addEventListener('click', () => {
      window.TLStore.markAllNotificationsRead();
      renderPopoverNotifications();
      updateNotificationBadges();
      showToast('All notifications marked as read', 'success');
    });

    // Page-level buttons
    document.getElementById('btn-notif-mark-all-read')?.addEventListener('click', () => {
      window.TLStore.markAllNotificationsRead();
      renderNotificationsPage();
      updateNotificationBadges();
      showToast('All notifications marked as read', 'success');
    });

    document.getElementById('btn-notif-clear-read')?.addEventListener('click', () => {
      window.TLStore.clearReadNotifications();
      renderNotificationsPage();
      updateNotificationBadges();
      showToast('Cleared read notifications', 'success');
    });

    // Close popovers on body click
    document.addEventListener('click', (e) => {
      if (!bellBtn?.contains(e.target) && !dropdown?.contains(e.target)) {
        dropdown?.classList.remove('show');
      }
      const quickMenu = document.getElementById('quick-action-menu');
      const quickBtn = document.getElementById('btn-header-quick-action');
      if (!quickBtn?.contains(e.target) && !quickMenu?.contains(e.target)) {
        quickMenu?.classList.remove('show');
      }
    });

    updateNotificationBadges();
  }

  function updateNotificationBadges() {
    const list = window.TLStore.getNotifications();
    const unread = list.filter(n => !n.isRead).length;

    const bellBadge = document.getElementById('header-bell-badge');
    const navUnreadBadge = document.getElementById('nav-unread-count');

    if (bellBadge) {
      bellBadge.style.display = unread > 0 ? 'block' : 'none';
    }

    if (navUnreadBadge) {
      if (unread > 0) {
        navUnreadBadge.style.display = 'inline-flex';
        navUnreadBadge.textContent = unread;
      } else {
        navUnreadBadge.style.display = 'none';
      }
    }
  }

  function renderPopoverNotifications() {
    const listContainer = document.getElementById('popover-notifications-list');
    if (!listContainer) return;

    const notifications = window.TLStore.getNotifications().slice(0, 5);

    if (notifications.length === 0) {
      listContainer.innerHTML = '<div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 0.82rem;">No notifications.</div>';
      return;
    }

    listContainer.innerHTML = notifications.map(n => {
      return `
        <div class="notif-popover-item ${n.isRead ? '' : 'unread'}" onclick="window.TLApp.handleNotificationClick('${n.id}')">
          <div style="font-weight: 700; color: var(--text-main); font-size: 0.84rem;">${n.title}</div>
          <p style="color: var(--text-muted); font-size: 0.76rem; margin-top: 2px;">${n.message}</p>
        </div>
      `;
    }).join('');
  }

  function renderNotificationsPage() {
    const container = document.getElementById('full-notifications-list');
    const emptyState = document.getElementById('notif-empty-state');
    if (!container) return;

    const notifications = window.TLStore.getNotifications();

    if (notifications.length === 0) {
      container.innerHTML = '';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';

    container.innerHTML = notifications.map(n => {
      let typeBadge = '<span class="badge badge-indigo">Notice</span>';
      if (n.type === 'due') typeBadge = '<span class="badge badge-danger">Fee Due</span>';
      else if (n.type === 'payment') typeBadge = '<span class="badge badge-success">Payment</span>';
      else if (n.type === 'extra') typeBadge = '<span class="badge badge-purple">Extra Class</span>';
      else if (n.type === 'class') typeBadge = '<span class="badge badge-primary">Schedule</span>';

      return `
        <div style="display:flex; justify-content:space-between; align-items:flex-start; padding: 16px 20px; border-bottom: 1px solid var(--border-color); background: ${n.isRead ? '#ffffff' : '#f8faff'};">
          <div style="flex:1;">
            <div style="display:flex; align-items:center; gap: 8px; margin-bottom: 4px;">
              ${typeBadge}
              <h4 style="font-size: 0.92rem; font-weight: 700; color: var(--text-main);">${n.title}</h4>
              <span style="font-size: 0.72rem; color: var(--text-muted);">${new Date(n.timestamp).toLocaleDateString()}</span>
            </div>
            <p style="font-size: 0.84rem; color: var(--text-muted);">${n.message}</p>
          </div>
          <div class="flex-wrap-gap">
            ${!n.isRead ? `<button class="btn btn-outline btn-xs" onclick="window.TLStore.markNotificationRead('${n.id}'); window.TLApp.refreshNotifications();">Mark Read</button>` : ''}
            <button class="btn btn-primary btn-xs" onclick="window.TLApp.handleNotificationClick('${n.id}')">View</button>
          </div>
        </div>
      `;
    }).join('');
  }

  function handleNotificationClick(notifId) {
    const n = window.TLStore.getNotifications().find(item => item.id === notifId);
    if (!n) return;

    window.TLStore.markNotificationRead(notifId);
    updateNotificationBadges();

    const dropdown = document.getElementById('header-notifications-dropdown');
    if (dropdown) dropdown.classList.remove('show');

    if (n.page === 'students' && n.idRef) {
      window.TLStudents.openProfile(n.idRef);
    } else if (n.page === 'schedule') {
      navigateTo('schedule');
    } else if (n.page === 'payments') {
      navigateTo('payments');
      if (n.idRef && n.idRef.startsWith('REC-')) {
        window.TLPayments.viewReceipt(n.idRef);
      }
    } else {
      navigateTo('dashboard');
    }
  }

  // 7. Universal Modal Controls
  function initModals() {
    // Close button triggers
    document.querySelectorAll('[data-close]').forEach(btn => {
      btn.addEventListener('click', () => {
        const modalId = btn.getAttribute('data-close');
        closeModal(modalId);
      });
    });

    // Close on backdrop click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          closeModal(overlay.id);
        }
      });
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(overlay => {
          closeModal(overlay.id);
        });
      }
    });
  }

  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
      // If no active modals remain, restore body scroll
      if (document.querySelectorAll('.modal-overlay.active').length === 0) {
        document.body.style.overflow = '';
      }
    }
  }

  // 8. Toast Alert Notifications
  function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="16" y2="12"/><line x1="12" x2="12.01" y1="8" y2="8"/></svg>';
    if (type === 'success') {
      iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>';
    } else if (type === 'danger') {
      iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" x2="9" y1="9" y2="15"/><line x1="9" x2="15" y1="9" y2="15"/></svg>';
    } else if (type === 'warning') {
      iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2.5"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" x2="12" y1="9" y2="13"/><line x1="12" x2="12.01" y1="17" y2="17"/></svg>';
    }

    toast.innerHTML = `
      ${iconSvg}
      <span style="flex:1;">${message}</span>
      <button style="background:none; border:none; font-size:1.1rem; cursor:pointer; color:var(--text-muted);">&times;</button>
    `;

    toast.querySelector('button').addEventListener('click', () => {
      toast.remove();
    });

    container.appendChild(toast);

    // Auto-dismiss after 4.5 seconds
    setTimeout(() => {
      if (toast.parentElement) {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        setTimeout(() => toast.remove(), 300);
      }
    }, 4500);
  }

  // Application Lifecycle Bootstrapper
  document.addEventListener('DOMContentLoaded', () => {
    initHeaderDate();
    initMobileSidebar();
    initGlobalSearch();
    initQuickActions();
    initNotifications();
    initModals();

    // Initialize Submodules
    if (window.TLDashboard) window.TLDashboard.init();
    if (window.TLStudents) window.TLStudents.init();
    if (window.TLSchedule) window.TLSchedule.init();
    if (window.TLAttendance) window.TLAttendance.init();
    if (window.TLPayments) window.TLPayments.init();
    if (window.TLReports) window.TLReports.init();
    if (window.TLSettings) window.TLSettings.init();

    initRouting();
  });

  // Expose App Core
  window.TLApp = {
    navigateTo: navigateTo,
    openModal: openModal,
    closeModal: closeModal,
    showToast: showToast,
    selectSearchResult: selectSearchResult,
    handleNotificationClick: handleNotificationClick,
    refreshNotifications: () => {
      renderNotificationsPage();
      updateNotificationBadges();
    }
  };

  window.TLStore.subscribe(() => {
    updateNotificationBadges();
  });
})();
