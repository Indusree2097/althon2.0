/**
 * TUTOR LEDGER — Centralized Reactive State Store & Persistence Layer
 * Handles LocalStorage synchronization, seed data, calculation engine,
 * transparent fee computations, and notification triggers.
 */

(function () {
  'use strict';

  const STORAGE_KEY = 'tutor_ledger_store_v2';

  // Default Tutor Settings
  const DEFAULT_SETTINGS = {
    tutorName: 'Prof. Palle Sharma',
    tutorTitle: 'Senior Mathematics & Physics Tutor',
    phone: '+91 98765 43210',
    email: 'palle.tutor@example.com',
    address: '42 Academic Heights, Bengaluru, KA',
    currency: 'INR',
    currencySymbol: '₹',
    defaultBilling: 'per_class',
    defaultDuration: 60,
    chargeAbsent: true,
    chargeCancelled: false,
    apiKey: 'AQ.Ab8RN6LD5G3Sfbo8Le48AR46enaVaHVahGP2onG825B9lHBOtQ'
  };

  // Helper date generators for realistic relative dates
  function getRelativeDateStr(offsetDays) {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    return d.toISOString().split('T')[0];
  }

  // Realistic Seed Data
  function getSeedData() {
    const today = getRelativeDateStr(0);
    const yesterday = getRelativeDateStr(-1);
    const twoDaysAgo = getRelativeDateStr(-2);
    const threeDaysAgo = getRelativeDateStr(-3);
    const tomorrow = getRelativeDateStr(1);
    const dayAfter = getRelativeDateStr(2);
    const nextWeek = getRelativeDateStr(5);

    const students = [
      {
        id: 'TL-2026-001',
        name: 'Aarav Nair',
        parentName: 'Ramesh Nair',
        phone: '+91 98450 12345',
        email: 'ramesh.nair@example.com',
        grade: 'Grade 10 / ICSE',
        subjects: 'Mathematics, Physics',
        startDate: getRelativeDateStr(-40),
        preferredTime: 'Mon, Wed, Fri at 4:30 PM',
        billingMethod: 'per_class',
        feeAmount: 600,
        dueDay: 5,
        status: 'active',
        notes: 'Targeting 95%+ in ICSE boards. Strong in algebra, working on coordinate geometry.',
        isSample: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 'TL-2026-002',
        name: 'Diya Sen',
        parentName: 'Suman Sen',
        phone: '+91 97420 54321',
        email: 'suman.sen@example.com',
        grade: 'Grade 12 / CBSE',
        subjects: 'Mathematics',
        startDate: getRelativeDateStr(-60),
        preferredTime: 'Tue, Thu, Sat at 6:00 PM',
        billingMethod: 'monthly',
        feeAmount: 4500,
        dueDay: 5,
        status: 'active',
        notes: 'Preparing for JEE Main & CBSE. Focus on Calculus and Vectors.',
        isSample: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 'TL-2026-003',
        name: 'Rohan Verma',
        parentName: 'Vikram Verma',
        phone: '+91 99801 87654',
        email: 'vikram.verma@example.com',
        grade: 'Grade 9 / CBSE',
        subjects: 'Science & Mathematics',
        startDate: getRelativeDateStr(-50),
        preferredTime: 'Mon, Wed at 6:00 PM',
        billingMethod: 'per_class',
        feeAmount: 500,
        dueDay: 1,
        status: 'active',
        notes: 'Needs conceptual reinforcement in linear equations.',
        isSample: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 'TL-2026-004',
        name: 'Ananya Patel',
        parentName: 'Bhavna Patel',
        phone: '+91 98200 98712',
        email: 'bhavna.patel@example.com',
        grade: 'Grade 11 / CBSE',
        subjects: 'Physics',
        startDate: getRelativeDateStr(-45),
        preferredTime: 'Wed, Fri at 7:00 PM',
        billingMethod: 'monthly',
        feeAmount: 5000,
        dueDay: 10,
        status: 'active',
        notes: 'Kinematics and Laws of Motion revision in progress.',
        isSample: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 'TL-2026-005',
        name: 'Kabir Mehta',
        parentName: 'Sunita Mehta',
        phone: '+91 99112 33445',
        email: 'sunita.mehta@example.com',
        grade: 'Grade 8 / Cambridge IGCSE',
        subjects: 'Mathematics',
        startDate: getRelativeDateStr(-30),
        preferredTime: 'Tue, Sat at 4:00 PM',
        billingMethod: 'per_class',
        feeAmount: 700,
        dueDay: 15,
        status: 'active',
        notes: 'Fast learner, preparing for AMC 8 / Math Olympiad.',
        isSample: true,
        createdAt: new Date().toISOString()
      }
    ];

    const classes = [
      // Past completed classes
      {
        id: 'CLS-2026-001',
        studentId: 'TL-2026-001',
        studentName: 'Aarav Nair',
        subject: 'Mathematics',
        date: threeDaysAgo,
        startTime: '16:30',
        endTime: '17:30',
        mode: 'in_person',
        venue: "Student's Home",
        isExtra: false,
        extraReason: '',
        extraChargeable: true,
        notes: 'Covered Quadratic Equations, Chapter 4 test review.',
        status: 'completed',
        isSample: true
      },
      {
        id: 'CLS-2026-002',
        studentId: 'TL-2026-003',
        studentName: 'Rohan Verma',
        subject: 'Science',
        date: twoDaysAgo,
        startTime: '18:00',
        endTime: '19:00',
        mode: 'in_person',
        venue: "Tutor's Studio",
        isExtra: false,
        extraReason: '',
        extraChargeable: true,
        notes: 'Atoms & Molecules revision.',
        status: 'completed',
        isSample: true
      },
      {
        id: 'CLS-2026-003',
        studentId: 'TL-2026-002',
        studentName: 'Diya Sen',
        subject: 'Mathematics',
        date: yesterday,
        startTime: '18:00',
        endTime: '19:15',
        mode: 'online',
        venue: 'meet.google.com/xyz-math',
        isExtra: false,
        extraReason: '',
        extraChargeable: true,
        notes: 'Integration by parts problem set discussion.',
        status: 'completed',
        isSample: true
      },
      // Classes Scheduled for TODAY
      {
        id: 'CLS-2026-004',
        studentId: 'TL-2026-001',
        studentName: 'Aarav Nair',
        subject: 'Physics',
        date: today,
        startTime: '16:30',
        endTime: '17:30',
        mode: 'in_person',
        venue: "Student's Home",
        isExtra: false,
        extraReason: '',
        extraChargeable: true,
        notes: 'Optics: Refraction and Snell’s Law experiments.',
        status: 'scheduled',
        isSample: true
      },
      {
        id: 'CLS-2026-005',
        studentId: 'TL-2026-004',
        studentName: 'Ananya Patel',
        subject: 'Physics',
        date: today,
        startTime: '19:00',
        endTime: '20:00',
        mode: 'online',
        venue: 'meet.google.com/phy-ananya',
        isExtra: false,
        extraReason: '',
        extraChargeable: true,
        notes: 'Rotational Dynamics review.',
        status: 'scheduled',
        isSample: true
      },
      // Upcoming Classes with an EXTRA Class
      {
        id: 'CLS-2026-006',
        studentId: 'TL-2026-005',
        studentName: 'Kabir Mehta',
        subject: 'Mathematics',
        date: tomorrow,
        startTime: '16:00',
        endTime: '17:00',
        mode: 'online',
        venue: 'zoom.us/j/987654321',
        isExtra: true,
        extraReason: 'Additional support on Modular Arithmetic for upcoming Math Olympiad',
        extraChargeable: true,
        notes: 'Olympiad worksheet level 2.',
        status: 'scheduled',
        isSample: true
      },
      {
        id: 'CLS-2026-007',
        studentId: 'TL-2026-002',
        studentName: 'Diya Sen',
        subject: 'Mathematics',
        date: dayAfter,
        startTime: '18:00',
        endTime: '19:00',
        mode: 'online',
        venue: 'meet.google.com/xyz-math',
        isExtra: false,
        extraReason: '',
        extraChargeable: true,
        notes: 'Definite integrals shortcut techniques.',
        status: 'scheduled',
        isSample: true
      },
      {
        id: 'CLS-2026-008',
        studentId: 'TL-2026-003',
        studentName: 'Rohan Verma',
        subject: 'Mathematics',
        date: nextWeek,
        startTime: '18:00',
        endTime: '19:00',
        mode: 'in_person',
        venue: "Tutor's Studio",
        isExtra: false,
        extraReason: '',
        extraChargeable: true,
        notes: 'Triangles congruence proofs.',
        status: 'scheduled',
        isSample: true
      }
    ];

    const attendance = [
      {
        id: 'ATT-2026-001',
        classId: 'CLS-2026-001',
        studentId: 'TL-2026-001',
        date: threeDaysAgo,
        status: 'Present',
        notes: 'Attended on time. Submitted completed homework.',
        timestamp: new Date(Date.now() - 3 * 86400000).toISOString(),
        isSample: true
      },
      {
        id: 'ATT-2026-002',
        classId: 'CLS-2026-002',
        studentId: 'TL-2026-003',
        date: twoDaysAgo,
        status: 'Absent',
        notes: 'Absent without prior intimation; charged as per policy.',
        timestamp: new Date(Date.now() - 2 * 86400000).toISOString(),
        isSample: true
      },
      {
        id: 'ATT-2026-003',
        classId: 'CLS-2026-003',
        studentId: 'TL-2026-002',
        date: yesterday,
        status: 'Present',
        notes: 'Active participation in integration problems.',
        timestamp: new Date(Date.now() - 1 * 86400000).toISOString(),
        isSample: true
      }
    ];

    const payments = [
      {
        id: 'REC-2026-001',
        studentId: 'TL-2026-001',
        studentName: 'Aarav Nair',
        amount: 2400,
        date: getRelativeDateStr(-5),
        method: 'UPI',
        ref: 'UPI-9284719284',
        appliedTo: 'September 2026 Class Settlement (4 classes)',
        notes: 'Paid via father Google Pay with thanks.',
        timestamp: new Date(Date.now() - 5 * 86400000).toISOString(),
        isSample: true
      },
      {
        id: 'REC-2026-002',
        studentId: 'TL-2026-002',
        studentName: 'Diya Sen',
        amount: 4500,
        date: getRelativeDateStr(-10),
        method: 'Bank Transfer',
        ref: 'NEFT-AXIS-91823',
        appliedTo: 'September 2026 Monthly Fee',
        notes: 'Online bank transfer acknowledged.',
        timestamp: new Date(Date.now() - 10 * 86400000).toISOString(),
        isSample: true
      },
      {
        id: 'REC-2026-003',
        studentId: 'TL-2026-004',
        studentName: 'Ananya Patel',
        amount: 2500,
        date: getRelativeDateStr(-2),
        method: 'UPI',
        ref: 'UPI-7382910482',
        appliedTo: 'October 2026 Partial Advance (50%)',
        notes: 'First installment received. Remaining ₹2,500 due on 10th.',
        timestamp: new Date(Date.now() - 2 * 86400000).toISOString(),
        isSample: true
      }
    ];

    const notifications = [
      {
        id: 'NOTIF-2026-001',
        title: 'Classes Scheduled for Today',
        message: 'You have 2 classes scheduled today: Aarav Nair (4:30 PM) and Ananya Patel (7:00 PM).',
        type: 'class',
        page: 'schedule',
        idRef: 'CLS-2026-004',
        timestamp: new Date().toISOString(),
        isRead: false
      },
      {
        id: 'NOTIF-2026-002',
        title: 'Overdue Fee Notice: Rohan Verma',
        message: 'Rohan Verma has an unsettled overdue balance of ₹1,500 due since 1st of the month.',
        type: 'due',
        page: 'payments',
        idRef: 'TL-2026-003',
        timestamp: new Date(Date.now() - 1 * 86400000).toISOString(),
        isRead: false
      },
      {
        id: 'NOTIF-2026-003',
        title: 'Extra Academic Support Class Scheduled',
        message: 'Performance extra class planned for Kabir Mehta on tomorrow at 4:00 PM (Modular Arithmetic).',
        type: 'extra',
        page: 'schedule',
        idRef: 'CLS-2026-006',
        timestamp: new Date().toISOString(),
        isRead: false
      },
      {
        id: 'NOTIF-2026-004',
        title: 'Fee Payment Received',
        message: 'Recorded payment of ₹2,500 from Ananya Patel via UPI (Receipt #REC-2026-003).',
        type: 'payment',
        page: 'payments',
        idRef: 'REC-2026-003',
        timestamp: new Date(Date.now() - 2 * 86400000).toISOString(),
        isRead: true
      }
    ];

    return {
      settings: DEFAULT_SETTINGS,
      students,
      classes,
      attendance,
      payments,
      notifications
    };
  }

  // State Container
  class TutorStore {
    constructor() {
      this.listeners = [];
      this.init();
    }

    init() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
          this.data = JSON.parse(raw);
          // Merge default settings in case of schema extension
          this.data.settings = Object.assign({}, DEFAULT_SETTINGS, this.data.settings || {});
        } else {
          this.resetToSeed();
        }
      } catch (e) {
        console.error('Failed to parse Tutor Ledger store from LocalStorage', e);
        this.resetToSeed();
      }
    }

    resetToSeed() {
      this.data = getSeedData();
      this.persist();
      this.notify();
    }

    clearAll() {
      this.data = {
        settings: Object.assign({}, DEFAULT_SETTINGS),
        students: [],
        classes: [],
        attendance: [],
        payments: [],
        notifications: []
      };
      this.persist();
      this.notify();
    }

    persist() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
      } catch (e) {
        console.error('LocalStorage write failed:', e);
      }
    }

    subscribe(listener) {
      this.listeners.push(listener);
      return () => {
        this.listeners = this.listeners.filter(l => l !== listener);
      };
    }

    notify() {
      this.listeners.forEach(fn => {
        try {
          fn(this.data);
        } catch (err) {
          console.error('Error in store listener:', err);
        }
      });
    }

    // -------------------------------------------------------------
    // SETTINGS METHODS
    // -------------------------------------------------------------
    getSettings() {
      return this.data.settings || DEFAULT_SETTINGS;
    }

    updateSettings(newSettings) {
      this.data.settings = Object.assign({}, this.data.settings, newSettings);
      this.persist();
      this.notify();
      return this.data.settings;
    }

    getCurrencySymbol() {
      const cur = (this.data.settings && this.data.settings.currency) || 'INR';
      switch (cur) {
        case 'USD': return '$';
        case 'EUR': return '€';
        case 'GBP': return '£';
        case 'AED': return 'AED ';
        case 'INR':
        default: return '₹';
      }
    }

    formatCurrency(amount) {
      const sym = this.getCurrencySymbol();
      const num = Number(amount) || 0;
      return `${sym}${num.toLocaleString('en-IN')}`;
    }

    // -------------------------------------------------------------
    // STUDENT METHODS
    // -------------------------------------------------------------
    getStudents() {
      return this.data.students || [];
    }

    getStudentById(id) {
      return (this.data.students || []).find(s => s.id === id) || null;
    }

    generateStudentId() {
      const year = new Date().getFullYear();
      const existing = (this.data.students || []).map(s => {
        const parts = s.id.split('-');
        return parts.length === 3 ? parseInt(parts[2], 10) : 0;
      });
      const maxNum = existing.length > 0 ? Math.max(...existing, 0) : 0;
      const nextNum = String(maxNum + 1).padStart(3, '0');
      return `TL-${year}-${nextNum}`;
    }

    saveStudent(studentData) {
      if (!this.data.students) this.data.students = [];

      if (studentData.id) {
        // Edit existing
        const idx = this.data.students.findIndex(s => s.id === studentData.id);
        if (idx !== -1) {
          this.data.students[idx] = Object.assign({}, this.data.students[idx], studentData, {
            updatedAt: new Date().toISOString()
          });
          this.persist();
          this.notify();
          return this.data.students[idx];
        }
      }

      // Add new
      const newStudent = Object.assign({}, studentData, {
        id: studentData.id || this.generateStudentId(),
        status: studentData.status || 'active',
        isSample: false,
        createdAt: new Date().toISOString()
      });

      this.data.students.push(newStudent);
      this.persist();
      this.notify();
      return newStudent;
    }

    deleteStudent(studentId) {
      // Archive or remove
      this.data.students = (this.data.students || []).filter(s => s.id !== studentId);
      this.persist();
      this.notify();
    }

    // -------------------------------------------------------------
    // CLASS SCHEDULING METHODS
    // -------------------------------------------------------------
    getClasses() {
      return this.data.classes || [];
    }

    getClassById(id) {
      return (this.data.classes || []).find(c => c.id === id) || null;
    }

    generateClassId() {
      const year = new Date().getFullYear();
      const existing = (this.data.classes || []).map(c => {
        const parts = c.id.split('-');
        return parts.length === 3 ? parseInt(parts[2], 10) : 0;
      });
      const maxNum = existing.length > 0 ? Math.max(...existing, 0) : 0;
      const nextNum = String(maxNum + 1).padStart(3, '0');
      return `CLS-${year}-${nextNum}`;
    }

    checkClassConflict(date, startTime, endTime, excludeClassId = null) {
      const classesOnDate = (this.data.classes || []).filter(c => {
        return c.date === date && c.id !== excludeClassId && c.status !== 'cancelled';
      });

      for (const c of classesOnDate) {
        // Simple 24h string time comparison e.g. "16:00" vs "17:00"
        if (
          (startTime >= c.startTime && startTime < c.endTime) ||
          (endTime > c.startTime && endTime <= c.endTime) ||
          (startTime <= c.startTime && endTime >= c.endTime)
        ) {
          return c; // returns the conflicting class
        }
      }
      return null;
    }

    saveClass(classData) {
      if (!this.data.classes) this.data.classes = [];

      if (classData.id) {
        const idx = this.data.classes.findIndex(c => c.id === classData.id);
        if (idx !== -1) {
          const old = this.data.classes[idx];
          // Check if rescheduled to keep history
          if (old.date !== classData.date || old.startTime !== classData.startTime) {
            classData.rescheduledFrom = `${old.date} ${old.startTime}`;
          }
          this.data.classes[idx] = Object.assign({}, old, classData);
          this.persist();
          this.notify();
          return this.data.classes[idx];
        }
      }

      const newClass = Object.assign({}, classData, {
        id: classData.id || this.generateClassId(),
        status: classData.status || 'scheduled',
        isSample: false,
        createdAt: new Date().toISOString()
      });

      this.data.classes.push(newClass);

      // Create in-app notification if extra class
      if (newClass.isExtra) {
        this.addNotification({
          title: 'Extra Academic Support Class Scheduled',
          message: `Scheduled extra session for ${newClass.studentName} on ${newClass.date} at ${newClass.startTime}. Reason: ${newClass.extraReason || 'Academic support'}`,
          type: 'extra',
          page: 'schedule',
          idRef: newClass.id
        });
      }

      this.persist();
      this.notify();
      return newClass;
    }

    updateClassStatus(classId, status) {
      const c = this.getClassById(classId);
      if (c) {
        c.status = status;
        this.persist();
        this.notify();
      }
    }

    deleteClass(classId) {
      this.data.classes = (this.data.classes || []).filter(c => c.id !== classId);
      this.data.attendance = (this.data.attendance || []).filter(a => a.classId !== classId);
      this.persist();
      this.notify();
    }

    // -------------------------------------------------------------
    // ATTENDANCE METHODS
    // -------------------------------------------------------------
    getAttendance() {
      return this.data.attendance || [];
    }

    getAttendanceByClassId(classId) {
      return (this.data.attendance || []).find(a => a.classId === classId) || null;
    }

    getAttendanceByStudentId(studentId) {
      return (this.data.attendance || []).filter(a => a.studentId === studentId);
    }

    saveAttendance(attData) {
      if (!this.data.attendance) this.data.attendance = [];

      // Check if attendance already exists for this class
      const existingIdx = this.data.attendance.findIndex(a => a.classId === attData.classId);

      const record = {
        id: existingIdx !== -1 ? this.data.attendance[existingIdx].id : `ATT-${Date.now()}`,
        classId: attData.classId,
        studentId: attData.studentId,
        date: attData.date,
        status: attData.status, // "Present" | "Absent" | "Late" | "Excused"
        notes: attData.notes || '',
        timestamp: new Date().toISOString(),
        isSample: false
      };

      if (existingIdx !== -1) {
        this.data.attendance[existingIdx] = record;
      } else {
        this.data.attendance.push(record);
      }

      // Mark the corresponding class as completed
      const cls = this.getClassById(attData.classId);
      if (cls && cls.status === 'scheduled') {
        cls.status = 'completed';
      }

      this.persist();
      this.notify();
      return record;
    }

    // -------------------------------------------------------------
    // PAYMENTS METHODS
    // -------------------------------------------------------------
    getPayments() {
      return this.data.payments || [];
    }

    getPaymentsByStudentId(studentId) {
      return (this.data.payments || []).filter(p => p.studentId === studentId);
    }

    generateReceiptNumber() {
      const year = new Date().getFullYear();
      const existing = (this.data.payments || []).map(p => {
        const parts = (p.id || '').split('-');
        return parts.length === 3 ? parseInt(parts[2], 10) : 0;
      });
      const maxNum = existing.length > 0 ? Math.max(...existing, 0) : 0;
      const nextNum = String(maxNum + 1).padStart(3, '0');
      return `REC-${year}-${nextNum}`;
    }

    recordPayment(payData) {
      if (!this.data.payments) this.data.payments = [];

      const student = this.getStudentById(payData.studentId);
      const studentName = student ? student.name : payData.studentName || 'Student';

      const newPayment = {
        id: payData.id || this.generateReceiptNumber(),
        studentId: payData.studentId,
        studentName: studentName,
        amount: Number(payData.amount),
        date: payData.date,
        method: payData.method || 'UPI',
        ref: payData.ref || '',
        appliedTo: payData.appliedTo || 'Fee Settlement',
        notes: payData.notes || '',
        timestamp: new Date().toISOString(),
        isSample: false
      };

      this.data.payments.push(newPayment);

      // Add Notification
      this.addNotification({
        title: 'Fee Payment Recorded',
        message: `Recorded payment of ${this.formatCurrency(newPayment.amount)} from ${studentName} via ${newPayment.method}. Receipt: ${newPayment.id}`,
        type: 'payment',
        page: 'payments',
        idRef: newPayment.id
      });

      this.persist();
      this.notify();
      return newPayment;
    }

    // -------------------------------------------------------------
    // NOTIFICATIONS METHODS
    // -------------------------------------------------------------
    getNotifications() {
      return this.data.notifications || [];
    }

    addNotification(notif) {
      if (!this.data.notifications) this.data.notifications = [];
      const newNotif = Object.assign({}, notif, {
        id: `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        timestamp: new Date().toISOString(),
        isRead: false
      });
      this.data.notifications.unshift(newNotif);
      this.persist();
      this.notify();
      return newNotif;
    }

    markNotificationRead(id) {
      const n = (this.data.notifications || []).find(item => item.id === id);
      if (n) {
        n.isRead = true;
        this.persist();
        this.notify();
      }
    }

    markAllNotificationsRead() {
      (this.data.notifications || []).forEach(n => { n.isRead = true; });
      this.persist();
      this.notify();
    }

    clearReadNotifications() {
      this.data.notifications = (this.data.notifications || []).filter(n => !n.isRead);
      this.persist();
      this.notify();
    }

    // -------------------------------------------------------------
    // TRANSPARENT FEE & BALANCE CALCULATION ENGINE
    // -------------------------------------------------------------
    /**
     * Calculates transparent itemized breakdown for a given student:
     * - Total fees generated
     * - Itemized fee entries (which classes or months generated fees)
     * - Total payments received
     * - Outstanding balance = Fees Generated - Payments
     * - Due date & Overdue status
     */
    calculateStudentLedger(studentId) {
      const student = this.getStudentById(studentId);
      if (!student) {
        return {
          totalFees: 0,
          totalPaid: 0,
          balance: 0,
          isOverdue: false,
          status: 'paid',
          entries: [],
          nextDueDate: null
        };
      }

      const settings = this.getSettings();
      const entries = [];
      let totalFees = 0;

      if (student.billingMethod === 'per_class') {
        // Per-Class calculation
        const studentClasses = (this.data.classes || []).filter(c => c.studentId === studentId);
        
        studentClasses.forEach(cls => {
          const att = this.getAttendanceByClassId(cls.id);
          let isChargeable = false;
          let reason = '';

          if (cls.status === 'completed' || att) {
            const attStatus = att ? att.status : 'Present';

            if (attStatus === 'Present' || attStatus === 'Late') {
              isChargeable = true;
              reason = `${attStatus} in class`;
            } else if (attStatus === 'Absent') {
              if (settings.chargeAbsent) {
                isChargeable = true;
                reason = 'Absent (Charged per tutor absence policy)';
              } else {
                isChargeable = false;
                reason = 'Absent (No charge per policy)';
              }
            } else if (attStatus === 'Excused') {
              isChargeable = false;
              reason = 'Excused Absence (No charge)';
            }
          } else if (cls.status === 'cancelled') {
            if (settings.chargeCancelled) {
              isChargeable = true;
              reason = 'Cancelled (Late cancellation fee applied)';
            } else {
              isChargeable = false;
              reason = 'Cancelled (No charge)';
            }
          }

          // If extra class marked non-chargeable explicitly
          if (cls.isExtra && cls.extraChargeable === false) {
            isChargeable = false;
            reason = 'Performance Extra Class (Complimentary / Free)';
          }

          if (isChargeable) {
            const fee = Number(student.feeAmount) || 0;
            totalFees += fee;
            entries.push({
              date: cls.date,
              description: `${cls.subject} Class (${cls.startTime} - ${cls.endTime}) ${cls.isExtra ? '[EXTRA CLASS]' : ''}`,
              chargeable: true,
              reason: reason,
              amount: fee,
              classId: cls.id
            });
          } else if (cls.status === 'completed' || cls.status === 'cancelled') {
            entries.push({
              date: cls.date,
              description: `${cls.subject} Class (${cls.startTime} - ${cls.endTime}) ${cls.isExtra ? '[EXTRA CLASS]' : ''}`,
              chargeable: false,
              reason: reason,
              amount: 0,
              classId: cls.id
            });
          }
        });
      } else {
        // Monthly fixed billing calculation
        // Compute billing periods from start date to current month
        const start = new Date(student.startDate || Date.now());
        const now = new Date();
        const startYear = start.getFullYear();
        const startMonth = start.getMonth(); // 0-indexed
        const curYear = now.getFullYear();
        const curMonth = now.getMonth();

        const totalMonths = Math.max(1, (curYear - startYear) * 12 + (curMonth - startMonth) + 1);

        for (let i = 0; i < totalMonths; i++) {
          const billingDate = new Date(startYear, startMonth + i, student.dueDay || 5);
          const monthLabel = billingDate.toLocaleString('default', { month: 'long', year: 'numeric' });
          const fee = Number(student.feeAmount) || 0;
          totalFees += fee;

          entries.push({
            date: billingDate.toISOString().split('T')[0],
            description: `Monthly Fixed Fee — ${monthLabel}`,
            chargeable: true,
            reason: 'Active monthly billing cycle',
            amount: fee,
            period: monthLabel
          });
        }
      }

      // Payments allocated
      const payments = this.getPaymentsByStudentId(studentId);
      const totalPaid = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      const balance = Math.max(0, totalFees - totalPaid);

      // Determine Next Due Date & Overdue Status
      const today = new Date();
      const currentDay = today.getDate();
      const dueDay = student.dueDay || 5;

      let nextDueDateObj = new Date(today.getFullYear(), today.getMonth(), dueDay);
      if (currentDay > dueDay && balance <= 0) {
        // If already passed and paid, next due is next month
        nextDueDateObj = new Date(today.getFullYear(), today.getMonth() + 1, dueDay);
      }
      const nextDueDateStr = nextDueDateObj.toISOString().split('T')[0];

      // Overdue logic:
      // If balance > 0 AND today's day of month is past dueDay OR student was billed in a prior month with unpaid balance
      let isOverdue = false;
      if (balance > 0) {
        if (currentDay > dueDay) {
          isOverdue = true;
        } else if (student.billingMethod === 'monthly' && totalFees > (Number(student.feeAmount) || 0) && balance >= (Number(student.feeAmount) || 0)) {
          isOverdue = true;
        }
      }

      let status = 'paid';
      if (balance > 0) {
        if (isOverdue) status = 'overdue';
        else if (totalPaid > 0) status = 'partially_paid';
        else status = 'pending';
      }

      return {
        totalFees,
        totalPaid,
        balance,
        isOverdue,
        status, // 'paid' | 'partially_paid' | 'pending' | 'overdue'
        entries,
        nextDueDate: nextDueDateStr,
        billingMethod: student.billingMethod
      };
    }

    // -------------------------------------------------------------
    // DASHBOARD & OVERALL METRICS CALCULATION
    // -------------------------------------------------------------
    getDashboardMetrics() {
      const students = this.getStudents();
      const activeStudents = students.filter(s => s.status === 'active');
      const classes = this.getClasses();
      const todayStr = new Date().toISOString().split('T')[0];

      const classesToday = classes.filter(c => c.date === todayStr && c.status !== 'cancelled');
      const completedClasses = classes.filter(c => c.status === 'completed');

      // Attendance Rate Calculation
      const attendance = this.getAttendance();
      const presentCount = attendance.filter(a => a.status === 'Present' || a.status === 'Late').length;
      const attRate = attendance.length > 0 ? Math.round((presentCount / attendance.length) * 100) : 100;

      // Fees & Dues aggregation
      let totalFeesExpected = 0;
      let totalPaymentsReceived = 0;
      let totalOutstanding = 0;
      let totalOverdue = 0;
      let overdueAccountsCount = 0;

      students.forEach(s => {
        const ledger = this.calculateStudentLedger(s.id);
        totalFeesExpected += ledger.totalFees;
        totalPaymentsReceived += ledger.totalPaid;
        totalOutstanding += ledger.balance;
        if (ledger.isOverdue && ledger.balance > 0) {
          totalOverdue += ledger.balance;
          overdueAccountsCount++;
        }
      });

      return {
        totalStudents: students.length,
        activeStudents: activeStudents.length,
        classesToday: classesToday.length,
        classesCompleted: completedClasses.length,
        attendanceRate: attRate,
        totalFeesExpected,
        totalPaymentsReceived,
        totalOutstanding,
        totalOverdue,
        overdueAccountsCount
      };
    }
  }

  // Attach to window
  window.TLStore = new TutorStore();
})();
