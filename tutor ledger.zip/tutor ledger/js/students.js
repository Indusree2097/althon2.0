/**
 * TUTOR LEDGER — Student Management Controller
 * Handles student directory table, search & filtering, sorting,
 * add/edit modal with validation, archive/deactivation,
 * and the 6-tab comprehensive student profile modal.
 */

(function () {
  'use strict';

  let currentProfileStudentId = null;

  function initStudents() {
    setupEventListeners();
    renderStudentsTable();
  }

  function setupEventListeners() {
    // Search & Filter listeners
    const searchInput = document.getElementById('students-search-input');
    if (searchInput) searchInput.addEventListener('input', renderStudentsTable);

    const filterStatus = document.getElementById('filter-student-status');
    if (filterStatus) filterStatus.addEventListener('change', renderStudentsTable);

    const filterDues = document.getElementById('filter-student-dues');
    if (filterDues) filterDues.addEventListener('change', renderStudentsTable);

    const sortBy = document.getElementById('sort-students-by');
    if (sortBy) sortBy.addEventListener('change', renderStudentsTable);

    const btnResetFilters = document.getElementById('btn-reset-student-filters');
    if (btnResetFilters) {
      btnResetFilters.addEventListener('click', () => {
        if (searchInput) searchInput.value = '';
        if (filterStatus) filterStatus.value = 'active';
        if (filterDues) filterDues.value = 'all';
        if (sortBy) sortBy.value = 'name_asc';
        renderStudentsTable();
      });
    }

    // Add Student Button
    const btnAddStudent = document.getElementById('btn-open-add-student-modal');
    if (btnAddStudent) {
      btnAddStudent.addEventListener('click', () => openStudentFormModal());
    }

    // Dynamic fee label on billing method change
    const billingSelect = document.getElementById('stu-billing-method');
    const feeLabel = document.getElementById('stu-fee-label');
    if (billingSelect && feeLabel) {
      billingSelect.addEventListener('change', () => {
        const sym = window.TLStore.getCurrencySymbol();
        if (billingSelect.value === 'per_class') {
          feeLabel.innerHTML = `Fee per Class (<span class="curr-sym">${sym}</span>) *`;
        } else {
          feeLabel.innerHTML = `Monthly Fixed Fee (<span class="curr-sym">${sym}</span>) *`;
        }
      });
    }

    // Student Form Submit
    const studentForm = document.getElementById('form-student');
    if (studentForm) {
      studentForm.addEventListener('submit', handleStudentFormSubmit);
    }

    // Profile Modal Tabs
    const tabButtons = document.querySelectorAll('.modal-tab');
    tabButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-tab');
        tabButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        document.querySelectorAll('.profile-tab-content').forEach(tab => {
          tab.classList.remove('active');
        });
        const targetEl = document.getElementById(targetId);
        if (targetEl) targetEl.classList.add('active');
      });
    });

    // Profile Action Buttons
    const btnEditFromProf = document.getElementById('btn-edit-student-from-profile');
    if (btnEditFromProf) {
      btnEditFromProf.addEventListener('click', () => {
        if (currentProfileStudentId) {
          window.TLApp.closeModal('modal-student-profile');
          openStudentFormModal(currentProfileStudentId);
        }
      });
    }

    const btnProfileRecordPay = document.getElementById('btn-profile-record-pay');
    if (btnProfileRecordPay) {
      btnProfileRecordPay.addEventListener('click', () => {
        if (currentProfileStudentId) {
          window.TLPayments.openRecordPaymentModal(currentProfileStudentId);
        }
      });
    }

    const btnProfileAddClass = document.getElementById('btn-profile-add-class');
    if (btnProfileAddClass) {
      btnProfileAddClass.addEventListener('click', () => {
        if (currentProfileStudentId) {
          window.TLSchedule.openScheduleModal(null, null, currentProfileStudentId);
        }
      });
    }
  }

  // 1. Render Students Table
  function renderStudentsTable() {
    const tbody = document.getElementById('students-table-tbody');
    const emptyState = document.getElementById('students-empty-state');
    if (!tbody) return;

    const searchTerm = (document.getElementById('students-search-input')?.value || '').toLowerCase().trim();
    const statusFilter = document.getElementById('filter-student-status')?.value || 'active';
    const duesFilter = document.getElementById('filter-student-dues')?.value || 'all';
    const sortVal = document.getElementById('sort-students-by')?.value || 'name_asc';

    let list = window.TLStore.getStudents();

    // Filter by Active / Inactive
    if (statusFilter !== 'all') {
      list = list.filter(s => s.status === statusFilter);
    }

    // Filter by Payment Status (calculated on the fly)
    if (duesFilter !== 'all') {
      list = list.filter(s => {
        const ledger = window.TLStore.calculateStudentLedger(s.id);
        if (duesFilter === 'paid') return ledger.balance === 0;
        if (duesFilter === 'pending') return ledger.balance > 0 && !ledger.isOverdue;
        if (duesFilter === 'overdue') return ledger.isOverdue && ledger.balance > 0;
        return true;
      });
    }

    // Filter by Search Query
    if (searchTerm) {
      list = list.filter(s => {
        return (
          s.name.toLowerCase().includes(searchTerm) ||
          s.id.toLowerCase().includes(searchTerm) ||
          (s.phone && s.phone.toLowerCase().includes(searchTerm)) ||
          (s.subjects && s.subjects.toLowerCase().includes(searchTerm)) ||
          (s.grade && s.grade.toLowerCase().includes(searchTerm)) ||
          (s.parentName && s.parentName.toLowerCase().includes(searchTerm))
        );
      });
    }

    // Sorting
    list.sort((a, b) => {
      if (sortVal === 'name_asc') return a.name.localeCompare(b.name);
      if (sortVal === 'name_desc') return b.name.localeCompare(a.name);
      if (sortVal === 'balance_desc') {
        const balA = window.TLStore.calculateStudentLedger(a.id).balance;
        const balB = window.TLStore.calculateStudentLedger(b.id).balance;
        return balB - balA;
      }
      if (sortVal === 'date_newest') {
        return (b.startDate || '').localeCompare(a.startDate || '');
      }
      return 0;
    });

    if (list.length === 0) {
      tbody.innerHTML = '';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';

    tbody.innerHTML = list.map(student => {
      const ledger = window.TLStore.calculateStudentLedger(student.id);

      let statusBadge = '<span class="badge badge-success">Active</span>';
      if (student.status === 'inactive') {
        statusBadge = '<span class="badge badge-neutral">Inactive</span>';
      }

      let payBadge = '<span class="badge badge-success">Paid</span>';
      if (ledger.balance > 0) {
        if (ledger.isOverdue) payBadge = '<span class="badge badge-danger">Overdue</span>';
        else if (ledger.totalPaid > 0) payBadge = '<span class="badge badge-warning">Partial</span>';
        else payBadge = '<span class="badge badge-warning">Pending</span>';
      }

      const billingText = student.billingMethod === 'per_class'
        ? `Per-Class (${window.TLStore.formatCurrency(student.feeAmount)})`
        : `Monthly (${window.TLStore.formatCurrency(student.feeAmount)})`;

      return `
        <tr>
          <td>
            <span class="badge badge-indigo font-mono font-size-11">${student.id}</span>
          </td>
          <td>
            <a href="javascript:void(0)" class="font-weight-600 text-main" onclick="window.TLStudents.openProfile('${student.id}')">
              ${student.name}
            </a>
            ${student.isSample ? '<span class="badge badge-neutral ml-1 font-size-10">Demo</span>' : ''}
          </td>
          <td>
            <span class="font-weight-500">${student.grade}</span>
            <div class="text-muted font-size-12">${student.subjects}</div>
          </td>
          <td>
            <div class="font-size-13">${student.parentName}</div>
            <a href="tel:${student.phone}" class="text-muted font-size-12">${student.phone}</a>
          </td>
          <td>
            <span class="font-size-13">${billingText}</span>
            <div class="text-muted font-size-11">Due day: ${student.dueDay}th</div>
          </td>
          <td>
            <div class="font-weight-700 ${ledger.balance > 0 ? (ledger.isOverdue ? 'text-danger' : 'text-warning') : 'text-success'}">
              ${window.TLStore.formatCurrency(ledger.balance)}
            </div>
            ${payBadge}
          </td>
          <td>${statusBadge}</td>
          <td>
            <div class="flex-wrap-gap">
              <button class="btn btn-outline btn-xs" onclick="window.TLStudents.openProfile('${student.id}')" title="View Full Profile">
                Profile
              </button>
              <button class="btn btn-primary btn-xs" onclick="window.TLPayments.openRecordPaymentModal('${student.id}')" title="Record Payment">
                Pay
              </button>
              <button class="btn btn-outline btn-xs" onclick="window.TLStudents.openStudentFormModal('${student.id}')" title="Edit Student">
                Edit
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // 2. Open Student Add / Edit Modal
  function openStudentFormModal(studentId = null) {
    const form = document.getElementById('form-student');
    const title = document.getElementById('modal-student-title');
    const idInput = document.getElementById('student-form-id');
    if (!form) return;

    form.reset();

    if (studentId) {
      const student = window.TLStore.getStudentById(studentId);
      if (!student) return;

      if (title) title.textContent = `Edit Student: ${student.name}`;
      if (idInput) idInput.value = student.id;

      document.getElementById('stu-name').value = student.name;
      document.getElementById('stu-parent').value = student.parentName;
      document.getElementById('stu-phone').value = student.phone;
      document.getElementById('stu-email').value = student.email || '';
      document.getElementById('stu-grade').value = student.grade;
      document.getElementById('stu-subjects').value = student.subjects;
      document.getElementById('stu-start-date').value = student.startDate;
      document.getElementById('stu-preferred-time').value = student.preferredTime || '';
      document.getElementById('stu-billing-method').value = student.billingMethod;
      document.getElementById('stu-fee-amount').value = student.feeAmount;
      document.getElementById('stu-due-day').value = student.dueDay || 5;
      document.getElementById('stu-status').value = student.status || 'active';
      document.getElementById('stu-notes').value = student.notes || '';
    } else {
      if (title) title.textContent = 'Add New Student';
      if (idInput) idInput.value = '';
      document.getElementById('stu-start-date').value = new Date().toISOString().split('T')[0];
      document.getElementById('stu-due-day').value = 5;
      document.getElementById('stu-billing-method').value = window.TLStore.getSettings().defaultBilling || 'per_class';
      document.getElementById('stu-fee-amount').value = 600;
    }

    // Trigger billing method label update
    const billingSelect = document.getElementById('stu-billing-method');
    if (billingSelect) billingSelect.dispatchEvent(new Event('change'));

    window.TLApp.openModal('modal-student');
  }

  // 3. Handle Student Form Submit with Validation
  function handleStudentFormSubmit(e) {
    e.preventDefault();

    const id = document.getElementById('student-form-id').value;
    const name = document.getElementById('stu-name').value.trim();
    const parentName = document.getElementById('stu-parent').value.trim();
    const phone = document.getElementById('stu-phone').value.trim();
    const email = document.getElementById('stu-email').value.trim();
    const grade = document.getElementById('stu-grade').value.trim();
    const subjects = document.getElementById('stu-subjects').value.trim();
    const startDate = document.getElementById('stu-start-date').value;
    const preferredTime = document.getElementById('stu-preferred-time').value.trim();
    const billingMethod = document.getElementById('stu-billing-method').value;
    const feeAmount = Number(document.getElementById('stu-fee-amount').value);
    const dueDay = Number(document.getElementById('stu-due-day').value) || 5;
    const status = document.getElementById('stu-status').value;
    const notes = document.getElementById('stu-notes').value.trim();

    // Validation
    if (!name || !parentName || !phone || !grade || !subjects || !startDate || isNaN(feeAmount) || feeAmount < 0) {
      window.TLApp.showToast('Please fill all required student fields correctly.', 'warning');
      return;
    }

    // Phone format check (must have at least 7 digits)
    const digitsOnly = phone.replace(/\D/g, '');
    if (digitsOnly.length < 7) {
      window.TLApp.showToast('Please enter a valid phone number with country/area code.', 'warning');
      return;
    }

    // Check accidental duplicate for new student
    if (!id) {
      const existing = window.TLStore.getStudents().find(s => {
        return s.name.toLowerCase() === name.toLowerCase() && s.phone.replace(/\D/g, '') === digitsOnly;
      });
      if (existing) {
        window.TLApp.showToast(`A student named ${name} with this phone number already exists (${existing.id}).`, 'warning');
        return;
      }
    }

    const saved = window.TLStore.saveStudent({
      id: id || undefined,
      name,
      parentName,
      phone,
      email,
      grade,
      subjects,
      startDate,
      preferredTime,
      billingMethod,
      feeAmount,
      dueDay,
      status,
      notes
    });

    window.TLApp.closeModal('modal-student');
    window.TLApp.showToast(`Student profile for "${saved.name}" saved successfully!`, 'success');
    renderStudentsTable();
  }

  // 4. Open Detailed Student Profile Modal (6 Tabs)
  function openProfile(studentId) {
    const student = window.TLStore.getStudentById(studentId);
    if (!student) {
      window.TLApp.showToast('Student record not found.', 'danger');
      return;
    }

    currentProfileStudentId = student.id;

    // Header info
    document.getElementById('prof-avatar').textContent = student.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
    document.getElementById('prof-name').textContent = student.name;
    document.getElementById('prof-id-badge').textContent = student.id;
    
    const statusBadge = document.getElementById('prof-status-badge');
    statusBadge.textContent = student.status === 'active' ? 'Active' : 'Inactive';
    statusBadge.className = `badge ${student.status === 'active' ? 'badge-success' : 'badge-neutral'} ml-1`;

    // Recalculate ledger
    const ledger = window.TLStore.calculateStudentLedger(student.id);

    // Summary statistics in Overview tab
    document.getElementById('prof-total-fees').textContent = window.TLStore.formatCurrency(ledger.totalFees);
    document.getElementById('prof-total-paid').textContent = window.TLStore.formatCurrency(ledger.totalPaid);
    
    const balEl = document.getElementById('prof-balance');
    balEl.textContent = window.TLStore.formatCurrency(ledger.balance);
    balEl.className = `stat-value ${ledger.balance > 0 ? (ledger.isOverdue ? 'text-danger' : 'text-warning') : 'text-success'}`;

    // Attendance stats
    const studentAtt = window.TLStore.getAttendanceByStudentId(student.id);
    const presentCount = studentAtt.filter(a => a.status === 'Present' || a.status === 'Late').length;
    const attRate = studentAtt.length > 0 ? Math.round((presentCount / studentAtt.length) * 100) : 100;
    document.getElementById('prof-att-rate').textContent = `${attRate}%`;

    // Tab 1: Overview fields
    document.getElementById('prof-detail-grade').textContent = student.grade;
    document.getElementById('prof-detail-subjects').textContent = student.subjects;
    document.getElementById('prof-detail-parent').textContent = student.parentName;
    document.getElementById('prof-detail-phone').textContent = student.phone;
    document.getElementById('prof-detail-email').textContent = student.email || 'None provided';
    document.getElementById('prof-detail-start-date').textContent = student.startDate;
    document.getElementById('prof-detail-preferred').textContent = student.preferredTime || 'Not set';
    document.getElementById('prof-detail-notes').textContent = student.notes || 'None';

    document.getElementById('prof-detail-billing-type').textContent = student.billingMethod === 'per_class' ? 'Per-Class Billing' : 'Monthly Fixed Billing';
    document.getElementById('prof-detail-fee-rate').textContent = `${window.TLStore.formatCurrency(student.feeAmount)} ${student.billingMethod === 'per_class' ? 'per class' : 'per month'}`;
    document.getElementById('prof-detail-due-day').textContent = `${student.dueDay}th of month`;
    document.getElementById('prof-detail-next-due').textContent = ledger.nextDueDate || '—';

    const payStatusEl = document.getElementById('prof-detail-pay-status');
    if (ledger.balance === 0) {
      payStatusEl.innerHTML = '<span class="badge badge-success">Paid in Full</span>';
    } else if (ledger.isOverdue) {
      payStatusEl.innerHTML = '<span class="badge badge-danger">Overdue Payment</span>';
    } else if (ledger.totalPaid > 0) {
      payStatusEl.innerHTML = '<span class="badge badge-warning">Partially Paid</span>';
    } else {
      payStatusEl.innerHTML = '<span class="badge badge-warning">Pending Payment</span>';
    }

    // Tab 2: Schedule
    renderProfileScheduleTab(student);

    // Tab 3: Attendance History
    renderProfileAttendanceTab(student);

    // Tab 4: Transparent Fee Calculation Audit
    renderProfileFeeAuditTab(student, ledger);

    // Tab 5: Payments Made
    renderProfilePaymentsTab(student);

    // Tab 6: Activity Timeline
    renderProfileActivityTab(student, ledger);

    // Default to first tab
    const firstTabBtn = document.querySelector('.modal-tab[data-tab="tab-prof-overview"]');
    if (firstTabBtn) firstTabBtn.click();

    window.TLApp.openModal('modal-student-profile');
  }

  function renderProfileScheduleTab(student) {
    const tbody = document.getElementById('prof-schedule-tbody');
    if (!tbody) return;

    const classes = window.TLStore.getClasses().filter(c => c.studentId === student.id)
      .sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));

    if (classes.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted p-3">No classes scheduled for this student yet.</td></tr>';
      return;
    }

    tbody.innerHTML = classes.map(c => {
      const att = window.TLStore.getAttendanceByClassId(c.id);
      let statusBadge = `<span class="badge ${c.status === 'completed' ? 'badge-success' : 'badge-neutral'}">${c.status}</span>`;
      if (att) {
        statusBadge = `<span class="badge ${att.status === 'Present' ? 'badge-success' : (att.status === 'Absent' ? 'badge-danger' : 'badge-warning')}">${att.status}</span>`;
      }

      return `
        <tr>
          <td>
            <span class="font-weight-600">${c.date}</span>
            <div class="text-muted font-size-11">${c.startTime} - ${c.endTime}</div>
          </td>
          <td>${c.subject}</td>
          <td>
            ${c.isExtra ? '<span class="badge badge-purple">Extra Class</span>' : '<span class="badge badge-neutral">Regular</span>'}
          </td>
          <td>${c.mode === 'online' ? 'Online' : 'In-Person'}</td>
          <td>${statusBadge}</td>
          <td>
            <button class="btn btn-outline btn-xs" onclick="window.TLAttendance.openAttendanceForClass('${c.id}')">
              Mark Attendance
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  function renderProfileAttendanceTab(student) {
    const tbody = document.getElementById('prof-attendance-tbody');
    if (!tbody) return;

    const attList = window.TLStore.getAttendanceByStudentId(student.id)
      .sort((a, b) => b.date.localeCompare(a.date));

    if (attList.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted p-3">No attendance records found.</td></tr>';
      return;
    }

    tbody.innerHTML = attList.map(a => {
      const cls = window.TLStore.getClassById(a.classId);
      const subject = cls ? cls.subject : '—';
      const type = cls && cls.isExtra ? '<span class="badge badge-purple">Extra Class</span>' : 'Regular';

      let statusBadge = '<span class="badge badge-success">Present</span>';
      if (a.status === 'Absent') statusBadge = '<span class="badge badge-danger">Absent</span>';
      else if (a.status === 'Late') statusBadge = '<span class="badge badge-warning">Late</span>';
      else if (a.status === 'Excused') statusBadge = '<span class="badge badge-indigo">Excused</span>';

      return `
        <tr>
          <td>${a.date}</td>
          <td>${subject}</td>
          <td>${type}</td>
          <td>${statusBadge}</td>
          <td class="font-size-12 text-muted">${a.notes || '—'}</td>
          <td class="font-size-11 text-muted">${new Date(a.timestamp).toLocaleString()}</td>
        </tr>
      `;
    }).join('');
  }

  function renderProfileFeeAuditTab(student, ledger) {
    const tbody = document.getElementById('prof-fees-audit-tbody');
    const expl = document.getElementById('prof-calc-formula-explanation');
    if (!tbody) return;

    if (student.billingMethod === 'per_class') {
      expl.innerHTML = `
        <strong>Per-Class Billing:</strong> Total Fees = Sum of completed chargeable classes × ${window.TLStore.formatCurrency(student.feeAmount)}/class.<br>
        <strong>Current Formula:</strong> ${ledger.entries.filter(e => e.chargeable).length} chargeable classes × ${window.TLStore.formatCurrency(student.feeAmount)} = <strong>${window.TLStore.formatCurrency(ledger.totalFees)}</strong> &minus; ${window.TLStore.formatCurrency(ledger.totalPaid)} (Paid) = <strong>${window.TLStore.formatCurrency(ledger.balance)}</strong> Balance.
      `;
    } else {
      expl.innerHTML = `
        <strong>Monthly Fixed Billing:</strong> Fixed flat fee of ${window.TLStore.formatCurrency(student.feeAmount)} per active billing month.<br>
        <strong>Current Formula:</strong> ${ledger.entries.length} billing periods × ${window.TLStore.formatCurrency(student.feeAmount)} = <strong>${window.TLStore.formatCurrency(ledger.totalFees)}</strong> &minus; ${window.TLStore.formatCurrency(ledger.totalPaid)} (Paid) = <strong>${window.TLStore.formatCurrency(ledger.balance)}</strong> Balance.
      `;
    }

    if (ledger.entries.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted p-3">No billable sessions or billing cycles generated yet.</td></tr>';
      return;
    }

    let runningFeeTotal = 0;

    tbody.innerHTML = ledger.entries.map(e => {
      if (e.chargeable) {
        runningFeeTotal += e.amount;
      }

      return `
        <tr>
          <td class="font-weight-600">${e.date}</td>
          <td>
            ${e.description}
            <div class="text-muted font-size-11">${e.reason}</div>
          </td>
          <td>
            ${e.chargeable ? '<span class="badge badge-success">Chargeable</span>' : '<span class="badge badge-neutral">No Charge</span>'}
          </td>
          <td class="font-weight-600 ${e.chargeable ? 'text-main' : 'text-muted'}">
            ${window.TLStore.formatCurrency(e.amount)}
          </td>
          <td class="font-weight-700 text-indigo font-mono">
            ${window.TLStore.formatCurrency(runningFeeTotal)}
          </td>
        </tr>
      `;
    }).join('');
  }

  function renderProfilePaymentsTab(student) {
    const tbody = document.getElementById('prof-payments-tbody');
    if (!tbody) return;

    const payments = window.TLStore.getPaymentsByStudentId(student.id)
      .sort((a, b) => b.date.localeCompare(a.date));

    if (payments.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted p-3">No payments recorded for this student yet.</td></tr>';
      return;
    }

    tbody.innerHTML = payments.map(p => {
      return `
        <tr>
          <td><span class="badge badge-indigo font-mono font-size-11">${p.id}</span></td>
          <td>${p.date}</td>
          <td class="font-weight-700 text-success">${window.TLStore.formatCurrency(p.amount)}</td>
          <td><span class="badge badge-neutral">${p.method}</span></td>
          <td class="font-mono font-size-11">${p.ref || '—'}</td>
          <td class="font-size-12 text-muted">${p.appliedTo || '—'}</td>
          <td>
            <button class="btn btn-outline btn-xs" onclick="window.TLPayments.viewReceipt('${p.id}')">
              Receipt
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  function renderProfileActivityTab(student, ledger) {
    const container = document.getElementById('prof-activity-timeline');
    if (!container) return;

    // Aggregate events
    const events = [];

    // Enrollment
    events.push({
      date: student.startDate,
      title: 'Student Enrolled in Tutor Ledger',
      desc: `Enrolled for ${student.subjects} (${student.grade}) with ${student.billingMethod === 'per_class' ? 'Per-Class' : 'Monthly'} fee arrangement of ${window.TLStore.formatCurrency(student.feeAmount)}.`,
      type: 'enroll'
    });

    // Classes & Attendance
    const classes = window.TLStore.getClasses().filter(c => c.studentId === student.id);
    classes.forEach(c => {
      const att = window.TLStore.getAttendanceByClassId(c.id);
      if (att) {
        events.push({
          date: c.date,
          title: `Attendance Marked: ${att.status} (${c.subject})`,
          desc: `${c.startTime} - ${c.endTime} session. Notes: ${att.notes || 'None'}.`,
          type: 'attendance'
        });
      } else {
        events.push({
          date: c.date,
          title: `Class Scheduled: ${c.subject}`,
          desc: `Planned for ${c.startTime} - ${c.endTime} (${c.isExtra ? 'Performance Extra Class' : 'Regular'}).`,
          type: 'class'
        });
      }
    });

    // Payments
    const payments = window.TLStore.getPaymentsByStudentId(student.id);
    payments.forEach(p => {
      events.push({
        date: p.date,
        title: `Payment Recorded: ${window.TLStore.formatCurrency(p.amount)}`,
        desc: `Receipt #${p.id} via ${p.method}. ${p.appliedTo ? 'Applied to: ' + p.appliedTo : ''}`,
        type: 'payment'
      });
    });

    // Sort descending by date
    events.sort((a, b) => b.date.localeCompare(a.date));

    container.innerHTML = events.map(ev => {
      let iconColor = '#4f46e5';
      if (ev.type === 'payment') iconColor = '#10b981';
      else if (ev.type === 'attendance') iconColor = '#0ea5e9';

      return `
        <div style="display:flex; gap: 14px; margin-bottom: 16px; position: relative;">
          <div style="width: 12px; height: 12px; border-radius: 50%; background: ${iconColor}; margin-top: 5px; flex-shrink: 0;"></div>
          <div style="flex: 1; padding-bottom: 12px; border-bottom: 1px solid var(--border-color);">
            <div style="display:flex; justify-content: space-between; align-items: center;">
              <h5 style="font-size: 0.88rem; font-weight: 700;">${ev.title}</h5>
              <span style="font-size: 0.72rem; color: var(--text-muted); font-weight: 500;">${ev.date}</span>
            </div>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 2px;">${ev.desc}</p>
          </div>
        </div>
      `;
    }).join('');
  }

  // Expose controller
  window.TLStudents = {
    init: initStudents,
    refresh: renderStudentsTable,
    openProfile: openProfile,
    openStudentFormModal: openStudentFormModal
  };

  window.TLStore.subscribe(() => {
    renderStudentsTable();
    if (currentProfileStudentId) {
      const modal = document.getElementById('modal-student-profile');
      if (modal && modal.classList.contains('active')) {
        openProfile(currentProfileStudentId);
      }
    }
  });
})();
